/* Lớp kết nối Supabase bằng fetch thuần (không cần thư viện).
 * Cung cấp: đăng ký, đăng nhập, quên/đặt lại mật khẩu, đồng bộ tiến độ, bảng xếp hạng, gộp dữ liệu.
 * Bảo mật dựa vào Row Level Security trong supabase/schema.sql, không phụ thuộc vào mã phía trình duyệt. */
(() => {
  'use strict';
  const root = typeof window !== 'undefined' ? window : globalThis;
  const CFG = root.CLOUD_CONFIG || {};
  const BASE = String(CFG.url || '').trim().replace(/\/+$/, '');
  const KEY = String(CFG.anonKey || '').trim();
  const configured = /^https?:\/\/[^\s]+$/.test(BASE) && KEY.length > 20;
  const SESSION_KEY = 'vocab1000.session.v1';

  class CloudError extends Error {
    constructor(message, code, status) { super(message); this.name = 'CloudError'; this.code = code || ''; this.status = status || 0; }
  }

  /* ---------- Thông báo lỗi tiếng Việt ---------- */
  function viMessage(code, msg, status) {
    const c = String(code || ''), m = String(msg || '').toLowerCase();
    if (c === 'invalid_credentials' || m.includes('invalid login credentials')) return 'Email hoặc mật khẩu không đúng.';
    if (c === 'user_already_exists' || m.includes('already registered')) return 'Email này đã được đăng ký. Hãy đăng nhập hoặc dùng “Quên mật khẩu”.';
    if (c === 'email_not_confirmed' || m.includes('email not confirmed')) return 'Bạn chưa xác nhận email. Hãy mở email xác nhận rồi đăng nhập lại.';
    if (c === 'weak_password' || m.includes('at least') && m.includes('characters')) return 'Mật khẩu quá yếu (cần ít nhất 6 ký tự).';
    if (c === 'same_password') return 'Mật khẩu mới phải khác mật khẩu cũ.';
    if (c === 'over_email_send_rate_limit' || c === 'over_request_rate_limit' || m.includes('rate limit') || status === 429) return 'Bạn thao tác quá nhanh hoặc đã gửi quá nhiều email. Hãy thử lại sau ít phút.';
    if (c === 'signup_disabled') return 'Máy chủ hiện không cho đăng ký tài khoản mới.';
    if (c === 'validation_failed' || m.includes('unable to validate email')) return 'Email không hợp lệ.';
    if (c === 'otp_expired' || m.includes('expired')) return 'Liên kết hoặc phiên đăng nhập đã hết hạn. Hãy thử lại.';
    if (c === '42P01' || c === 'PGRST205') return 'Máy chủ chưa được cài bảng dữ liệu. Hãy chạy file supabase/schema.sql (xem README).';
    if (status === 401 || status === 403) return 'Phiên đăng nhập không hợp lệ. Hãy đăng nhập lại.';
    return msg ? `Lỗi máy chủ: ${msg}` : `Lỗi máy chủ (mã ${status || '?'}).`;
  }

  /* ---------- Phiên đăng nhập ---------- */
  function readSession() { try { return JSON.parse(localStorage.getItem(SESSION_KEY)); } catch (e) { return null; } }
  function writeSession(s) {
    try { if (s) localStorage.setItem(SESSION_KEY, JSON.stringify(s)); else localStorage.removeItem(SESSION_KEY); } catch (e) { /* bỏ qua */ }
  }
  let session = configured ? readSession() : null;

  function userFrom(u) {
    u = u || {};
    const meta = u.user_metadata || {};
    return { id: u.id || '', email: u.email || '', name: meta.display_name || '' };
  }
  function setSessionFromToken(t) {
    const prevName = session && session.user ? session.user.name : '';
    const user = userFrom(t.user);
    if (!user.name) user.name = prevName;
    session = {
      access_token: t.access_token,
      refresh_token: t.refresh_token,
      expires_at: t.expires_at || Math.floor(Date.now() / 1000) + (t.expires_in || 3600),
      user
    };
    writeSession(session);
    return session;
  }

  /* ---------- HTTP ---------- */
  async function http(path, opts = {}) {
    const headers = Object.assign({ apikey: KEY, 'Content-Type': 'application/json' }, opts.headers || {});
    if (opts.token) headers.Authorization = 'Bearer ' + opts.token;
    let res;
    try {
      res = await fetch(BASE + path, { method: opts.method || 'GET', headers, body: opts.body === undefined ? undefined : JSON.stringify(opts.body) });
    } catch (e) {
      throw new CloudError('Không kết nối được máy chủ. Hãy kiểm tra mạng rồi thử lại.', 'network', 0);
    }
    const text = await res.text();
    let data = null;
    if (text) { try { data = JSON.parse(text); } catch (e) { data = text; } }
    if (!res.ok) {
      const d = data && typeof data === 'object' ? data : {};
      const code = d.error_code || d.code || d.error || '';
      const msg = d.msg || d.message || d.error_description || d.hint || '';
      throw new CloudError(viMessage(code, msg, res.status), String(code), res.status);
    }
    return data;
  }

  let refreshing = null;
  function refresh() {
    if (!session || !session.refresh_token) return Promise.reject(new CloudError('Bạn chưa đăng nhập.', 'no_session', 401));
    if (refreshing) return refreshing;
    refreshing = (async () => {
      try {
        const t = await http('/auth/v1/token?grant_type=refresh_token', { method: 'POST', body: { refresh_token: session.refresh_token } });
        setSessionFromToken(t);
      } catch (e) {
        if (e.status >= 400 && e.status < 500) { session = null; writeSession(null); }   // chỉ đăng xuất khi máy chủ từ chối
        throw e;
      } finally { refreshing = null; }
    })();
    return refreshing;
  }
  async function authed(path, opts = {}) {
    if (!session) throw new CloudError('Bạn chưa đăng nhập.', 'no_session', 401);
    if (session.expires_at - Date.now() / 1000 < 60) await refresh();
    try {
      return await http(path, Object.assign({}, opts, { token: session.access_token }));
    } catch (e) {
      if (e.status === 401 && session) {
        await refresh();
        return http(path, Object.assign({}, opts, { token: session.access_token }));
      }
      throw e;
    }
  }

  const redirectParam = () => {
    try {
      const l = root.location;
      if (l && /^https?:$/.test(l.protocol)) return '?redirect_to=' + encodeURIComponent(l.origin + l.pathname);
    } catch (e) { /* bỏ qua */ }
    return '';
  };

  /* ---------- Tài khoản ---------- */
  async function signUp(email, password, name) {
    const r = await http('/auth/v1/signup' + redirectParam(), { method: 'POST', body: { email, password, data: { display_name: name } } });
    if (r && r.access_token) { setSessionFromToken(r); return { session, needsConfirm: false }; }
    // Khi bật xác nhận email, email đã tồn tại sẽ trả về user "giả" không có identities.
    if (r && Array.isArray(r.identities) && r.identities.length === 0) throw new CloudError(viMessage('user_already_exists'), 'user_already_exists', 422);
    if (r && r.user && Array.isArray(r.user.identities) && r.user.identities.length === 0) throw new CloudError(viMessage('user_already_exists'), 'user_already_exists', 422);
    return { session: null, needsConfirm: true };
  }
  async function signIn(email, password) {
    const t = await http('/auth/v1/token?grant_type=password', { method: 'POST', body: { email, password } });
    setSessionFromToken(t);
    return session;
  }
  async function signOut() {
    const tok = session && session.access_token;
    session = null; writeSession(null);
    if (tok) { try { await http('/auth/v1/logout', { method: 'POST', token: tok }); } catch (e) { /* bỏ qua */ } }
  }
  async function recover(email) {
    await http('/auth/v1/recover' + redirectParam(), { method: 'POST', body: { email } });
  }
  async function updatePassword(password) {
    await authed('/auth/v1/user', { method: 'PUT', body: { password } });
  }
  async function setName(name) {
    await authed('/auth/v1/user', { method: 'PUT', body: { data: { display_name: name } } });
    if (session) { session.user.name = name; writeSession(session); }
  }
  async function loadUser() {
    const u = await authed('/auth/v1/user');
    if (session) { session.user = userFrom(u); writeSession(session); }
    return session;
  }

  /* Xử lý liên kết trong email (xác nhận đăng ký, đặt lại mật khẩu): Supabase gắn token vào phần # của URL. */
  async function consumeAuthHash() {
    if (!configured) return null;
    const l = root.location;
    const q = String((l && l.hash) || '').replace(/^#\/?/, '');
    if (!/(^|&)(access_token|error)=/.test(q)) return null;
    const p = new URLSearchParams(q);
    const clean = () => { try { root.history.replaceState(null, '', l.pathname + l.search); } catch (e) { /* bỏ qua */ } };
    if (p.get('error')) {
      const code = p.get('error_code') || p.get('error');
      const msg = viMessage(code, p.get('error_description') || '', 400);
      clean();
      return { error: msg };
    }
    session = {
      access_token: p.get('access_token'),
      refresh_token: p.get('refresh_token') || '',
      expires_at: Number(p.get('expires_at')) || Math.floor(Date.now() / 1000) + Number(p.get('expires_in') || 3600),
      user: { id: '', email: '', name: '' }
    };
    writeSession(session);
    clean();
    const type = p.get('type') || 'signup';
    try { await loadUser(); } catch (e) { return { error: e.message }; }
    return { type };
  }

  /* ---------- Dữ liệu ---------- */
  async function fetchProgress() {
    const rows = await authed(`/rest/v1/user_progress?select=data,updated_at&user_id=eq.${encodeURIComponent(session.user.id)}`);
    return Array.isArray(rows) && rows[0] ? rows[0] : null;
  }
  async function pushProgress(data) {
    await authed('/rest/v1/user_progress?on_conflict=user_id', {
      method: 'POST', headers: { Prefer: 'resolution=merge-duplicates,return=minimal' },
      body: { user_id: session.user.id, data, updated_at: new Date().toISOString() }
    });
  }
  async function pushProfile(p) {
    await authed('/rest/v1/profiles?on_conflict=id', {
      method: 'POST', headers: { Prefer: 'resolution=merge-duplicates,return=minimal' },
      body: { id: session.user.id, display_name: p.name, learned: p.learned, streak: p.streak, week_learned: p.week, updated_at: new Date().toISOString() }
    });
  }
  async function leaderboard(by) {
    const order = by === 'week' ? 'week_learned.desc,learned.desc' : 'learned.desc,streak.desc';
    return authed(`/rest/v1/profiles?select=id,display_name,learned,streak,week_learned&order=${order}&limit=50`);
  }

  /* ---------- Gộp tiến độ giữa thiết bị và máy chủ ---------- */
  function merge(local, remote) {
    local = local || {}; remote = remote || {};
    const lt = Number(local.updatedAt) || 0, rt = Number(remote.updatedAt) || 0;
    const pref = rt > lt ? remote : local;
    const out = { goal: pref.goal || local.goal || remote.goal || 10, slow: !!pref.slow, updatedAt: Math.max(lt, rt), words: {}, log: {} };
    const lw = local.words || {}, rw = remote.words || {};
    for (const id of new Set([...Object.keys(lw), ...Object.keys(rw)])) {
      const a = lw[id], b = rw[id];
      if (!a) out.words[id] = b;
      else if (!b) out.words[id] = a;
      else {
        const ta = a.ts || 0, tb = b.ts || 0;
        out.words[id] = tb > ta ? b : ta > tb ? a : (a.learned || !b.learned ? a : b);
      }
    }
    const ll = local.log || {}, rl = remote.log || {};
    for (const d of new Set([...Object.keys(ll), ...Object.keys(rl)])) {
      const a = ll[d] || {}, b = rl[d] || {};
      out.log[d] = { learned: Math.max(a.learned || 0, b.learned || 0), reviewed: Math.max(a.reviewed || 0, b.reviewed || 0) };
    }
    return out;
  }

  root.Cloud = {
    configured,
    session: () => session,
    signUp, signIn, signOut, recover, updatePassword, setName, loadUser, refresh,
    consumeAuthHash, fetchProgress, pushProgress, pushProfile, leaderboard, merge, viMessage
  };
})();
