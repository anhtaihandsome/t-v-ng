/* Từ Vựng 1000 – ứng dụng tự học từ vựng tiếng Anh (JS thuần, không cần build).
 * Dữ liệu từ: data/vocab.js  |  Tiến độ: localStorage (khóa STORAGE_KEY). */
(() => {
  'use strict';

  /* ================= Cấu hình ================= */
  const TARGET = 1000;                       // mục tiêu tổng số từ
  const STORAGE_KEY = 'vocab1000.progress.v1';
  const INTERVALS = [1, 2, 4, 7, 15, 30];    // số ngày giữa các lần ôn (hộp Leitner 0..5)
  const GOALS = [10, 15, 20, 30, 50];        // mục tiêu/ngày gợi ý
  const QUIZ_SIZE = 20;                      // số từ tối đa mỗi phiên ôn tập

  const TOPICS = window.VOCAB_TOPICS || [];
  const VOCAB = window.VOCAB || [];
  const BY_ID = new Map(VOCAB.map(w => [w.id, w]));
  const TOPIC = new Map(TOPICS.map(t => [t.id, t]));
  const POS_VI = {
    noun: 'danh từ', verb: 'động từ', adjective: 'tính từ', adverb: 'trạng từ',
    'phrasal verb': 'cụm động từ', preposition: 'giới từ', conjunction: 'liên từ', pronoun: 'đại từ'
  };

  const Cloud = window.Cloud || { configured: false, session: () => null };

  /* ================= Tiện ích ================= */
  const $ = (s, el = document) => el.querySelector(s);
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const pad = n => String(n).padStart(2, '0');
  const dkey = (d = new Date()) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const toDate = k => { const [y, m, d] = k.split('-').map(Number); return new Date(y, m - 1, d); };
  const addDays = (k, n) => { const d = toDate(k); d.setDate(d.getDate() + n); return dkey(d); };
  const diffDays = (a, b) => Math.round((toDate(b) - toDate(a)) / 864e5);
  const norm = s => String(s).normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/đ/g, 'd').replace(/Đ/g, 'd').toLowerCase();
  const shuffle = a => { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
  const posVi = p => String(p).split(',').map(x => POS_VI[x.trim()] || x.trim()).join(', ');
  const topicName = id => (TOPIC.get(id) || {}).name || id;
  const topicIcon = id => (TOPIC.get(id) || {}).icon || '📘';
  const SEARCH = new Map(VOCAB.map(w => [w.id, norm(`${w.word} ${w.vi}`)]));

  let toastTimer;
  function toast(msg) {
    const t = $('#toast');
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.remove('show'), 2800);
  }

  /* ================= Lưu trữ tiến độ ================= */
  const defaults = () => ({ goal: 10, slow: false, words: {}, log: {}, updatedAt: 0, owner: '' });
  function sanitize(s) {
    const d = defaults();
    if (!s || typeof s !== 'object') return d;
    const out = Object.assign(d, s);
    if (!Number.isInteger(out.goal) || out.goal < 1 || out.goal > 200) out.goal = 10;
    if (typeof out.words !== 'object' || !out.words) out.words = {};
    if (typeof out.log !== 'object' || !out.log) out.log = {};
    out.slow = !!out.slow;
    out.updatedAt = Number(out.updatedAt) || 0;
    out.owner = typeof out.owner === 'string' ? out.owner : '';
    return out;
  }
  /* ---- Hồ sơ trên thiết bị (đăng nhập bằng tên, không cần máy chủ). Chỉ dùng khi chưa bật tài khoản trực tuyến. ---- */
  const PROFILES_KEY = 'vocab1000.profiles.v1';
  function readProfiles() {
    try {
      const p = JSON.parse(localStorage.getItem(PROFILES_KEY));
      if (p && Array.isArray(p.list)) {
        return { current: typeof p.current === 'string' ? p.current : '', list: p.list.filter(x => x && typeof x.id === 'string' && typeof x.name === 'string') };
      }
    } catch (e) { /* bỏ qua */ }
    return { current: '', list: [] };
  }
  const PF = Cloud.configured ? { current: '', list: [] } : readProfiles();
  if (PF.current && !PF.list.some(p => p.id === PF.current)) PF.current = '';
  function savePF() { try { localStorage.setItem(PROFILES_KEY, JSON.stringify(PF)); } catch (e) { /* bỏ qua */ } }
  const keyFor = id => (id ? STORAGE_KEY + '.p.' + id : STORAGE_KEY);
  const curKey = () => keyFor(PF.current);
  const curProfile = () => PF.list.find(p => p.id === PF.current) || null;

  function loadKey(k) {
    try { return sanitize(JSON.parse(localStorage.getItem(k))); } catch (e) { return defaults(); }
  }
  let S = loadKey(curKey());
  /* persist: ghi xuống trình duyệt; save: ghi + đánh dấu có thay đổi + hẹn đồng bộ lên máy chủ */
  function persist() {
    try { localStorage.setItem(curKey(), JSON.stringify(S)); }
    catch (e) { toast('Không lưu được tiến độ (trình duyệt đang chặn lưu trữ).'); }
  }
  function save() { S.updatedAt = Date.now(); persist(); scheduleSync(); }

  const EMPTY = Object.freeze({});
  const getW = id => S.words[id] || EMPTY;
  function setW(id, patch) { S.words[id] = Object.assign({}, S.words[id], patch, { ts: Date.now() }); save(); }
  function bump(kind) {
    const k = dkey();
    const l = S.log[k] || (S.log[k] = { learned: 0, reviewed: 0 });
    l[kind] = (l[kind] || 0) + 1;
  }

  /* ================= Logic học & ôn ================= */
  const learnedCount = () => VOCAB.reduce((n, w) => n + (getW(w.id).learned ? 1 : 0), 0);
  const favCount = () => VOCAB.reduce((n, w) => n + (getW(w.id).fav ? 1 : 0), 0);
  const learnedToday = () => (S.log[dkey()] || EMPTY).learned || 0;

  function streak() {
    const act = k => { const l = S.log[k]; return !!l && ((l.learned || 0) + (l.reviewed || 0)) > 0; };
    let d = dkey();
    if (!act(d)) d = addDays(d, -1);
    let n = 0;
    while (act(d)) { n++; d = addDays(d, -1); }
    return n;
  }

  function lessons() {
    const n = S.goal, out = [];
    for (let i = 0; i < VOCAB.length; i += n) {
      const ids = VOCAB.slice(i, i + n).map(w => w.id);
      const topics = [...new Set(ids.map(id => BY_ID.get(id).topic))];
      out.push({ day: out.length + 1, ids, topics });
    }
    return out;
  }
  const currentLesson = () => lessons().find(l => l.ids.some(id => !getW(id).learned)) || null;
  const lessonDone = l => l.ids.reduce((n, id) => n + (getW(id).learned ? 1 : 0), 0);

  const isDue = (s, today = dkey()) => !!s.learned && (!!s.flag || !s.due || s.due <= today);
  function dueQueue() {
    const t = dkey();
    return VOCAB
      .filter(w => isDue(getW(w.id), t))
      .map(w => {
        const s = getW(w.id);
        const over = s.due ? Math.max(0, diffDays(s.due, t)) : 0;
        return { id: w.id, score: (s.flag ? 5 : 0) + (s.wrong || 0) * 2 + over };
      })
      .sort((a, b) => b.score - a.score)
      .map(x => x.id);
  }

  function markLearned(id, needReview) {
    const t = dkey(), s = getW(id), first = !s.learned;
    const p = { learned: true, last: t };
    if (needReview) { p.flag = true; p.due = t; }
    else if (first) { p.box = 0; p.due = addDays(t, INTERVALS[0]); p.flag = false; }
    if (first) bump('learned');
    setW(id, p);
  }
  function unlearn(id) {
    setW(id, { learned: false, flag: false, box: 0, due: null });
  }
  /* assisted: trả lời đúng nhưng đã dùng gợi ý → không tăng cấp, mai ôn lại. */
  function applyAnswer(id, ok, assisted) {
    const t = dkey(), s = getW(id), p = { last: t };
    if (ok && assisted) {
      p.box = s.box || 0; p.due = addDays(t, 1); p.right = (s.right || 0) + 1;
    } else if (ok) {
      const box = Math.min((s.box || 0) + 1, INTERVALS.length - 1);
      p.box = box; p.due = addDays(t, INTERVALS[box]); p.right = (s.right || 0) + 1;
      if (box >= 3) p.flag = false;
    } else {
      p.box = 0; p.due = t; p.wrong = (s.wrong || 0) + 1; p.flag = true;
    }
    bump('reviewed');
    setW(id, p);
  }

  /* ================= Phát âm ================= */
  /* Tùy chọn riêng của từng thiết bị (không đồng bộ lên tài khoản vì mỗi máy có giọng đọc khác nhau). */
  const PREF_KEY = 'vocab1000.prefs.v1';
  const prefs = Object.assign({ mode: 'type', voice: '', real: true }, (() => {
    try { return JSON.parse(localStorage.getItem(PREF_KEY)) || {}; } catch (e) { return {}; }
  })());
  if (prefs.mode !== 'type' && prefs.mode !== 'choice') prefs.mode = 'type';
  function savePrefs() { try { localStorage.setItem(PREF_KEY, JSON.stringify(prefs)); } catch (e) { /* bỏ qua */ } }

  let voices = [];
  let warnedVoice = false;
  const hasTTS = () => 'speechSynthesis' in window && !!window.SpeechSynthesisUtterance;
  function refreshVoices() { if ('speechSynthesis' in window) voices = speechSynthesis.getVoices() || []; }
  refreshVoices();
  if ('speechSynthesis' in window && speechSynthesis.addEventListener) {
    speechSynthesis.addEventListener('voiceschanged', () => {
      const had = voices.length; refreshVoices();
      if (!had && voices.length && typeof currentRouteName === 'function' && currentRouteName() === 'settings') settingsView();
    });
  }

  /* Chấm điểm giọng: ưu tiên en-GB, giọng "tự nhiên/neural/cao cấp", tránh giọng máy móc (eSpeak). */
  function voiceScore(v) {
    const lang = String(v.lang || '').replace('_', '-'), n = String(v.name || '');
    if (!/^en/i.test(lang)) return -1;
    let s = /^en-GB$/i.test(lang) ? 100 : /^en-(IE|AU|NZ|ZA)$/i.test(lang) ? 40 : /^en-US$/i.test(lang) ? 20 : 10;
    if (/natural|online|neural/i.test(n)) s += 60;
    if (/premium|enhanced/i.test(n)) s += 40;
    if (/google/i.test(n)) s += 25;
    if (/sonia|libby|ryan|daniel|serena|kate|oliver|martha|arthur|stephanie/i.test(n)) s += 20;
    if (/espeak|compact/i.test(n)) s -= 60;
    return s;
  }
  function englishVoices() {
    refreshVoices();
    return voices.map(v => ({ v, s: voiceScore(v) })).filter(x => x.s >= 0).sort((a, b) => b.s - a.s).map(x => x.v);
  }
  function bestVoice() {
    const list = englishVoices();
    if (prefs.voice) { const v = list.find(x => x.voiceURI === prefs.voice || x.name === prefs.voice); if (v) return v; }
    return list[0] || null;
  }

  /* Bản ghi âm thật (người đọc) từ dịch vụ miễn phí dictionaryapi.dev; chỉ dùng khi có bản Anh-Anh. */
  const audioCache = new Map();   // từ → url | null
  let currentAudio = null, speakTok = 0;
  const isSingleWord = t => /^[A-Za-z][A-Za-z'-]*$/.test(String(t));
  async function realAudioUrl(word) {
    if (audioCache.has(word)) return audioCache.get(word);
    let url = null, definitive = false;
    let timer;
    try {
      const ctl = typeof AbortController !== 'undefined' ? new AbortController() : null;
      timer = setTimeout(() => { if (ctl) ctl.abort(); }, 4000);
      const r = await fetch('https://api.dictionaryapi.dev/v2/entries/en/' + encodeURIComponent(word), ctl ? { signal: ctl.signal } : undefined);
      if (r.ok) {
        const d = await r.json(), all = [];
        (Array.isArray(d) ? d : []).forEach(e => (e.phonetics || []).forEach(p => { if (p && p.audio) all.push(String(p.audio)); }));
        url = all.find(a => /^https:\/\//.test(a) && /(-uk|-gb)\.mp3(\?|$)|\/en\/gb\//i.test(a)) || null;
        definitive = true;
      } else if (r.status === 404) definitive = true;
    } catch (e) { /* mạng lỗi: dùng giọng thiết bị */ }
    clearTimeout(timer);
    if (definitive) audioCache.set(word, url);
    return url;
  }
  const prefetchAudio = word => { if (prefs.real && isSingleWord(word) && !audioCache.has(word.toLowerCase())) realAudioUrl(word.toLowerCase()); };

  function stopSpeech() {
    if (currentAudio) { try { currentAudio.pause(); } catch (e) { /* bỏ qua */ } currentAudio = null; }
    if ('speechSynthesis' in window) { try { speechSynthesis.cancel(); } catch (e) { /* bỏ qua */ } }
  }
  function speakTts(text) {
    if (!hasTTS()) { toast('Trình duyệt này chưa hỗ trợ phát âm. Hãy thử Chrome, Edge hoặc Safari bản mới.'); return; }
    const v = bestVoice();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = v ? v.lang : 'en-GB';
    if (v) u.voice = v;
    if (!warnedVoice && voices.length) {
      if (!v) { warnedVoice = true; toast('Thiết bị chưa có giọng tiếng Anh. Xem Cài đặt → Phát âm để biết cách cài giọng chuẩn.'); }
      else if (!/en[-_]GB/i.test(v.lang)) { warnedVoice = true; toast('Thiết bị chưa có giọng Anh-Anh, đang dùng giọng tiếng Anh khác. Xem Cài đặt → Phát âm.'); }
    }
    u.rate = S.slow ? 0.7 : 0.95;
    speechSynthesis.speak(u);
  }
  async function speak(text) {
    stopSpeech();
    const tok = ++speakTok;
    if (prefs.real && isSingleWord(text) && typeof Audio !== 'undefined') {
      const key = text.toLowerCase();
      const url = audioCache.has(key) ? audioCache.get(key) : await realAudioUrl(key);   // đã tải trước thì phát ngay trong cú chạm
      if (tok !== speakTok) return;
      if (url) {
        try {
          const a = new Audio(url);
          currentAudio = a;
          a.playbackRate = S.slow ? 0.8 : 1;
          a.onerror = () => { if (tok === speakTok) { currentAudio = null; speakTts(text); } };
          await a.play();
          return;
        } catch (e) { if (tok !== speakTok) return; currentAudio = null; }
      }
    }
    speakTts(text);
  }

  /* ================= Hiển thị chung ================= */
  const app = $('#app');
  function view(html) { app.innerHTML = html; window.scrollTo(0, 0); }

  const camUrl = w => `https://dictionary.cambridge.org/dictionary/english/${encodeURIComponent(w.word.trim().replace(/\s+/g, '-'))}`;
  const camLink = w => `<a class="cam-link" href="${camUrl(w)}" target="_blank" rel="noopener noreferrer">Tra Cambridge ↗</a>`;
  const speakBtn = (text, label, cls = 'icon-btn sm') =>
    `<button type="button" class="${cls}" data-act="speak" data-text="${esc(text)}" aria-label="${esc(label)}">🔊</button>`;
  const favBtn = (id, cls = 'icon-btn') => {
    const on = !!getW(id).fav;
    return `<button type="button" class="${cls} fav ${on ? 'on' : ''}" data-act="fav" data-id="${id}" aria-pressed="${on}" aria-label="Yêu thích">★</button>`;
  };
  const statusTag = id => {
    const s = getW(id);
    if (!s.learned) return '<span class="tag">Chưa học</span>';
    return s.flag ? '<span class="tag warn">Cần ôn</span>' : '<span class="tag ok">Đã học</span>';
  };

  /* ================= Điều hướng ================= */
  const NAV = [
    ['', 'Tổng quan', '🏠'], ['learn', 'Học', '📖'], ['review', 'Ôn tập', '🔁'],
    ['words', 'Từ vựng', '🔎'], ['rank', 'Xếp hạng', '🏆']
  ];
  function buildNav() {
    const html = NAV.map(([r, label, icon]) =>
      `<a href="#/${r}" data-route="${r}"><span aria-hidden="true">${icon}</span><span>${label}</span>` +
      (r === 'review' ? '<b class="nav-badge" hidden></b>' : '') + '</a>').join('');
    $('#navTop').innerHTML = html;
    $('#navBottom').innerHTML = html;
    updateHeader();
  }
  function updateHeader() {
    const cs = Cloud && Cloud.configured ? Cloud.session() : null;
    const lp = !Cloud.configured ? curProfile() : null;
    const who = cs ? (cs.user.name || cs.user.email) : lp ? lp.name : '';
    const s = who ? true : null;
    const initial = s ? esc(who.trim().charAt(0).toUpperCase() || '?') : '👤';
    const label = s ? `Tài khoản: ${esc(who)}` : 'Đăng nhập / Tài khoản';
    $('#headActions').innerHTML =
      `<a class="head-btn ${s ? 'signed' : ''}" href="#/account" aria-label="${label}" title="${label}">${initial}</a>` +
      '<a class="head-btn" href="#/settings" aria-label="Cài đặt" title="Cài đặt">⚙️</a>';
  }
  function updateNav(name) {
    const cur = name === 'plan' ? 'learn' : name;
    document.querySelectorAll('[data-route]').forEach(a => {
      const on = a.dataset.route === cur;
      a.classList.toggle('active', on);
      if (on) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current');
    });
    const n = dueQueue().length;
    document.querySelectorAll('.nav-badge').forEach(b => { b.textContent = n > 99 ? '99+' : n; b.hidden = n === 0; });
  }

  /* ================= Tổng quan ================= */
  function dashboardView() {
    const learned = learnedCount();
    const pct = Math.min(100, learned / TARGET * 100);
    const C = 2 * Math.PI * 49;
    const tl = learnedToday(), goal = S.goal;
    const due = dueQueue().length;
    const cur = currentLesson();
    const goalMet = tl >= goal;

    const topicRows = TOPICS.map(t => {
      const ids = VOCAB.filter(w => w.topic === t.id);
      const n = ids.reduce((c, w) => c + (getW(w.id).learned ? 1 : 0), 0);
      return `<div class="topic-row">
        <span>${t.icon} ${esc(t.name)}</span><span class="muted">${n}/${ids.length}</span>
        <div class="bar" role="progressbar" aria-valuemin="0" aria-valuemax="${ids.length}" aria-valuenow="${n}" aria-label="${esc(t.name)}"><i style="width:${ids.length ? n / ids.length * 100 : 0}%"></i></div>
      </div>`;
    }).join('');

    const cta = cur
      ? `<a class="btn" href="#/learn">${goalMet ? 'Học thêm' : (tl ? 'Học tiếp' : 'Bắt đầu bài hôm nay')} · Ngày ${cur.day}</a>`
      : `<a class="btn" href="#/words">Xem tất cả từ</a>`;

    view(`
      <div class="stack">
        <section class="card hero">
          <div class="hero-main">
            <svg class="ring" viewBox="0 0 120 120" role="img" aria-label="Đã học ${learned} trên ${TARGET} từ">
              <circle class="track" cx="60" cy="60" r="49"></circle>
              <circle class="val" cx="60" cy="60" r="49" stroke-dasharray="${(pct / 100 * C).toFixed(1)} ${C.toFixed(1)}"></circle>
              <text x="60" y="62">${Math.round(pct)}%</text>
              <text class="sub" x="60" y="80">hoàn thành</text>
            </svg>
            <div>
              <h1>${learned} / ${TARGET} từ</h1>
              <p class="muted">${goalMet ? '🎉 Bạn đã đạt mục tiêu hôm nay!' : 'Mỗi ngày một ít, bạn sẽ đi rất xa.'}</p>
            </div>
          </div>
          <div class="row">${cta}<a class="btn btn-soft" href="#/plan">Lộ trình</a></div>
        </section>

        <section class="stats" aria-label="Thống kê">
          <div class="card stat">
            <div class="label">Mục tiêu hôm nay</div>
            <div class="num">${Math.min(tl, goal)}/${goal}</div>
            <div class="bar" role="progressbar" aria-valuemin="0" aria-valuemax="${goal}" aria-valuenow="${Math.min(tl, goal)}" aria-label="Mục tiêu hôm nay"><i style="width:${Math.min(100, tl / goal * 100)}%"></i></div>
          </div>
          <div class="card stat">
            <div class="label">Chuỗi ngày học</div>
            <div class="num">🔥 ${streak()}</div>
            <div class="sub">ngày liên tiếp</div>
          </div>
          <div class="card stat">
            <div class="label">Cần ôn tập</div>
            <div class="num">${due}</div>
            <a class="sub link" href="#/review">${due ? 'Ôn ngay →' : 'Chưa có từ đến hạn'}</a>
          </div>
          <div class="card stat">
            <div class="label">Từ yêu thích</div>
            <div class="num">★ ${favCount()}</div>
            <a class="sub link" href="#/words" data-filter="fav">Xem danh sách →</a>
          </div>
        </section>

        <section class="card">
          <h2 class="page-title" style="font-size:18px;margin-bottom:6px">Tiến độ theo chủ đề</h2>
          ${topicRows || '<p class="muted">Chưa có dữ liệu chủ đề.</p>'}
        </section>

        ${Cloud.configured && !Cloud.session() ? '<a class="card promo" href="#/account"><b>👥 Học cùng bạn bè</b><span class="muted">Đăng nhập để đồng bộ tiến độ giữa các thiết bị và xem bảng xếp hạng →</span></a>' : ''}
        ${!Cloud.configured && !curProfile() ? '<a class="card promo" href="#/account"><b>👤 Đăng nhập bằng tên</b><span class="muted">Tạo hồ sơ để mỗi người trên máy này có tiến độ riêng →</span></a>' : ''}

        ${VOCAB.length < TARGET ? `<p class="muted">Kho dữ liệu hiện có <b>${VOCAB.length}</b>/${TARGET} từ. Xem README để bổ sung thêm.</p>` : ''}
      </div>`);
  }

  /* ================= Học theo ngày ================= */
  let sess = null;   // phiên học / ôn hiện tại

  function learnView(dayArg) {
    const ls = lessons();
    if (!ls.length) { view('<div class="card empty"><p>Chưa có dữ liệu từ vựng.</p></div>'); return; }
    let lesson;
    if (dayArg) {
      lesson = ls[Number(dayArg) - 1];
      if (!lesson) { view('<div class="card empty"><p>Không tìm thấy bài học này.</p><p><a class="btn" href="#/plan">Về lộ trình</a></p></div>'); return; }
    } else {
      lesson = currentLesson();
    }
    if (!lesson) {
      view(`<div class="card empty stack"><div class="big">🏆</div>
        <h1 class="page-title">Bạn đã học hết ${VOCAB.length} từ trong kho dữ liệu!</h1>
        <p class="muted">Hãy ôn tập đều đặn, hoặc bổ sung thêm từ mới (xem README).</p>
        <div class="row" style="justify-content:center"><a class="btn" href="#/review">Ôn tập</a><a class="btn btn-soft" href="#/plan">Lộ trình</a></div></div>`);
      return;
    }
    const pending = lesson.ids.filter(id => !getW(id).learned);
    sess = { type: 'learn', day: lesson.day, ids: pending.length ? pending : lesson.ids, i: 0, lessonIds: lesson.ids, replay: !pending.length };
    renderLearn();
  }

  function renderLearn() {
    const n = sess.ids.length, w = BY_ID.get(sess.ids[sess.i]);
    prefetchAudio(w.word);                 // tải sẵn bản ghi âm để bấm 🔊 là phát ngay
    view(`
      <div class="lesson-head">
        <a class="link" href="#/plan">← Lộ trình</a>
        <span class="muted">Ngày ${sess.day}${sess.replay ? ' (xem lại)' : ''} · ${sess.i + 1}/${n}</span>
      </div>
      <div class="bar" role="progressbar" aria-valuemin="0" aria-valuemax="${n}" aria-valuenow="${sess.i}" aria-label="Tiến độ bài học"><i style="width:${sess.i / n * 100}%"></i></div>
      <article class="card flash">
        <div class="flash-top"><span class="chip">${topicIcon(w.topic)} ${esc(topicName(w.topic))}</span>${favBtn(w.id)}</div>
        <h1 class="flash-word" lang="en">${esc(w.word)}</h1>
        <div class="flash-meta"><span class="ipa">${esc(w.ipa)}</span><span class="pos">${esc(posVi(w.pos))}</span></div>
        <button type="button" class="btn btn-soft" data-act="speak" data-text="${esc(w.word)}">🔊 Nghe phát âm</button>
        <div class="flash-vi">${esc(w.vi)}</div>
        <div class="example">
          <p class="ex-en" lang="en">${esc(w.ex)} ${speakBtn(w.ex, 'Nghe câu ví dụ')}</p>
          <p class="ex-vi">${esc(w.exVi)}</p>
        </div>
        ${w.note ? `<p class="note">💡 ${esc(w.note)}</p>` : ''}
        ${camLink(w)}
      </article>
      <div class="actions-row">
        <button type="button" class="btn btn-ghost" data-act="learn-prev" aria-label="Từ trước" ${sess.i === 0 ? 'disabled' : ''}>◀</button>
        <button type="button" class="btn btn-warn" data-act="learn-next" data-review="1">Cần ôn lại</button>
        <button type="button" class="btn" data-act="learn-next">Đã hiểu ✓</button>
      </div>`);
  }

  function learnDone() {
    const ids = sess.lessonIds;
    const flagged = ids.filter(id => getW(id).flag).length;
    const learned = ids.filter(id => getW(id).learned);
    const nextLesson = lessons()[sess.day];
    view(`
      <div class="card flash">
        <div style="font-size:48px">🎉</div>
        <h1 class="page-title" style="margin:0">Hoàn thành bài ngày ${sess.day}!</h1>
        <p class="muted">${learned.length} từ đã học${flagged ? `, trong đó ${flagged} từ được đánh dấu cần ôn` : ''}.</p>
        <div class="stack" style="width:100%">
          ${learned.length >= 4 ? `<button type="button" class="btn btn-block" data-act="quiz-lesson">Kiểm tra nhanh ${Math.min(learned.length, QUIZ_SIZE)} từ</button>` : ''}
          ${nextLesson ? `<a class="btn btn-soft btn-block" href="#/learn/${nextLesson.day}">Học tiếp ngày ${nextLesson.day}</a>` : ''}
          <a class="btn btn-ghost btn-block" href="#/">Về tổng quan</a>
        </div>
      </div>`);
  }

  /* ================= Trắc nghiệm (ôn tập) ================= */
  /* ---- Điền từ theo gợi ý ---- */
  const letterCount = w => (w.word.match(/[a-z]/gi) || []).length;
  function hintPattern(word, reveal) {
    let shown = 0;
    return [...word].map(ch => {
      if (ch === ' ') return '  ';
      if (!/[a-z]/i.test(ch)) return ch;
      if (shown < reveal) { shown++; return ch; }
      return '_';
    }).join(' ');
  }
  /* Che từ trong câu ví dụ (kể cả dạng biến đổi như parents, raised). Không che được thì không hiện câu. */
  function blankSentence(w) {
    const stem = t => (t.length > 3 && /e$/i.test(t) ? t.slice(0, -1) : t);
    const re = new RegExp('\\b' + w.word.split(/\s+/).map(t => stem(t).replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '[a-z]*').join('\\s+') + '\\b', 'i');
    return re.test(w.ex) ? w.ex.replace(re, '＿＿＿＿＿') : '';
  }
  const normAns = s => String(s).normalize('NFC').toLowerCase().replace(/[’‘]/g, "'").replace(/\s+/g, ' ').trim();
  function lev(a, b) {
    const m = a.length, n = b.length; if (!m) return n; if (!n) return m;
    let prev = Array.from({ length: n + 1 }, (_, j) => j);
    for (let i = 1; i <= m; i++) {
      const cur = [i];
      for (let j = 1; j <= n; j++) cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
      prev = cur;
    }
    return prev[n];
  }
  /* 'ok' | 'near' (sai 1 chữ) | 'wrong'. Chấp nhận biến thể chính tả Anh/Mỹ trong trường alt, và "to + động từ". */
  function checkAnswer(w, raw) {
    const a = normAns(raw).replace(/^to /, w.pos.includes('verb') ? '' : 'to ');
    const accepted = [w.word, ...(w.alt || [])].map(normAns);
    if (accepted.includes(a) || accepted.includes(normAns(raw))) return 'ok';
    if (a.length >= 4 && accepted.some(x => lev(a, x) === 1)) return 'near';
    return 'wrong';
  }

  function makeQuestion(id) {
    if (prefs.mode === 'type') return { id, dir: 'type', reveal: 1, listened: false };
    const w = BY_ID.get(id);
    const dir = Math.random() < 0.5 ? 'en2vi' : 'vi2en';
    const pool = VOCAB.filter(x => x.id !== id && x.vi !== w.vi);
    const same = shuffle(pool.filter(x => x.pos === w.pos));
    const rest = shuffle(pool.filter(x => x.pos !== w.pos));
    const dist = same.concat(rest).slice(0, 3);
    return { id, dir, opts: shuffle([w, ...dist]).map(x => x.id) };
  }
  function startQuiz(ids, title, back) {
    if (ids.length < 1 || (prefs.mode !== 'type' && VOCAB.length < 4)) { toast('Chưa đủ từ để tạo bài kiểm tra.'); return; }
    sess = { type: 'quiz', title, back, q: shuffle(ids).map(makeQuestion), i: 0, right: 0, wrong: [], locked: false };
    renderQuiz();
  }
  function renderQuiz() {
    const n = sess.q.length, q = sess.q[sess.i], w = BY_ID.get(q.id);
    sess.locked = false;
    if (q.dir === 'type') { renderTyped(q, w, n); return; }
    const prompt = q.dir === 'en2vi'
      ? `<div class="q-label">Chọn nghĩa đúng của từ:</div>
         <h1 class="flash-word" lang="en">${esc(w.word)}</h1>
         <div class="flash-meta"><span class="ipa">${esc(w.ipa)}</span><span class="pos">${esc(posVi(w.pos))}</span></div>
         <button type="button" class="btn btn-soft" data-act="speak" data-text="${esc(w.word)}">🔊 Nghe</button>`
      : `<div class="q-label">Chọn từ tiếng Anh có nghĩa:</div>
         <h1 class="q-vi">${esc(w.vi)}</h1>
         <div class="flash-meta"><span class="pos">${esc(posVi(w.pos))}</span></div>`;
    const opts = q.opts.map(id => {
      const o = BY_ID.get(id);
      return `<button type="button" class="opt" data-act="quiz-pick" data-id="${id}" ${q.dir === 'vi2en' ? 'lang="en"' : ''}>${esc(q.dir === 'en2vi' ? o.vi : o.word)}</button>`;
    }).join('');
    view(`
      <div class="lesson-head">
        <a class="link" href="${esc(sess.back)}">✕ Thoát</a>
        <span class="muted">${esc(sess.title)} · ${sess.i + 1}/${n}</span>
      </div>
      <div class="bar" role="progressbar" aria-valuemin="0" aria-valuemax="${n}" aria-valuenow="${sess.i}" aria-label="Tiến độ"><i style="width:${sess.i / n * 100}%"></i></div>
      <article class="card flash">
        ${prompt}
        <div class="opts">${opts}</div>
        <div id="fb" class="feedback" hidden></div>
      </article>`);
  }
  function quizPick(el) {
    if (!sess || sess.type !== 'quiz' || sess.locked) return;
    sess.locked = true;
    const q = sess.q[sess.i], w = BY_ID.get(q.id), ok = el.dataset.id === q.id;
    app.querySelectorAll('.opt').forEach(b => {
      b.disabled = true;
      if (b.dataset.id === q.id) b.classList.add('correct');
    });
    if (!ok) el.classList.add('wrong');
    applyAnswer(q.id, ok);
    if (ok) sess.right++; else sess.wrong.push(q.id);
    const last = sess.i === sess.q.length - 1;
    const fb = $('#fb');
    fb.hidden = false;
    fb.innerHTML = `
      <strong>${ok ? 'Chính xác! 🎉' : 'Chưa đúng, hãy ghi nhớ nhé.'}</strong>
      <div><b lang="en">${esc(w.word)}</b> <span class="ipa">${esc(w.ipa)}</span> · ${esc(w.vi)}</div>
      <p class="ex-en" lang="en">${esc(w.ex)} ${speakBtn(w.ex, 'Nghe câu ví dụ')}</p>
      <p class="ex-vi">${esc(w.exVi)}</p>
      <button type="button" class="btn" data-act="quiz-next">${last ? 'Xem kết quả' : 'Câu tiếp theo'}</button>`;
    fb.querySelector('.btn').focus({ preventScroll: false });
  }
  function renderTyped(q, w, n) {
    const blank = blankSentence(w), L = letterCount(w);
    prefetchAudio(w.word);
    view(`
      <div class="lesson-head">
        <a class="link" href="${esc(sess.back)}">✕ Thoát</a>
        <span class="muted">${esc(sess.title)} · ${sess.i + 1}/${n}</span>
      </div>
      <div class="bar" role="progressbar" aria-valuemin="0" aria-valuemax="${n}" aria-valuenow="${sess.i}" aria-label="Tiến độ"><i style="width:${sess.i / n * 100}%"></i></div>
      <article class="card flash">
        <div class="q-label">Gõ từ tiếng Anh có nghĩa:</div>
        <h1 class="q-vi">${esc(w.vi)}</h1>
        <div class="flash-meta"><span class="pos">${esc(posVi(w.pos))}</span><span class="muted">${L} chữ cái</span></div>
        <div id="hintPat" class="hint-pat" lang="en" aria-live="polite">${esc(hintPattern(w.word, q.reveal))}</div>
        ${blank ? `<div class="example"><p class="ex-en" lang="en">${esc(blank)}</p><p class="ex-vi">${esc(w.exVi)}</p></div>` : ''}
        <form id="typeForm" data-quiz-form class="type-form" autocomplete="off" novalidate>
          <input id="ans" class="field ans" type="text" inputmode="text" enterkeyhint="done" autocapitalize="off" autocorrect="off" autocomplete="off" spellcheck="false" lang="en" aria-label="Nhập từ tiếng Anh" placeholder="Gõ từ tiếng Anh…">
          <button type="submit" class="btn btn-block">Kiểm tra</button>
          <div class="row type-tools">
            <button type="button" class="btn btn-soft" data-act="type-hint" id="hintBtn" ${L <= 2 ? 'disabled' : ''}>💡 Gợi ý thêm</button>
            <button type="button" class="btn btn-ghost" data-act="type-listen">🔊 Nghe gợi ý</button>
            <button type="button" class="btn btn-ghost" data-act="type-skip">Bỏ qua</button>
          </div>
        </form>
        <div id="fb" class="feedback" hidden></div>
      </article>`);
    const a = $('#ans');
    if (a && a.focus) a.focus({ preventScroll: true });
  }
  function typedHint() {
    if (!sess || sess.type !== 'quiz' || sess.locked) return;
    const q = sess.q[sess.i]; if (q.dir !== 'type') return;
    const w = BY_ID.get(q.id), L = letterCount(w);
    if (q.reveal < L - 1) q.reveal++;
    $('#hintPat').textContent = hintPattern(w.word, q.reveal);
    if (q.reveal >= L - 1) $('#hintBtn').disabled = true;
  }
  function typedListen() {
    if (!sess || sess.type !== 'quiz' || sess.locked) return;
    const q = sess.q[sess.i]; if (q.dir !== 'type') return;
    q.listened = true;
    speak(BY_ID.get(q.id).word);
  }
  function typedSubmit(skip) {
    if (!sess || sess.type !== 'quiz' || sess.locked) return;
    const q = sess.q[sess.i]; if (q.dir !== 'type') return;
    const w = BY_ID.get(q.id), input = $('#ans'), raw = skip ? '' : String(input.value || '');
    if (!skip && !normAns(raw)) { toast('Hãy gõ từ tiếng Anh, hoặc bấm “Bỏ qua” nếu chưa nhớ.'); return; }
    sess.locked = true;
    const res = skip ? 'skip' : checkAnswer(w, raw);
    const ok = res === 'ok', assisted = q.reveal > 1 || q.listened;
    applyAnswer(q.id, ok, ok && assisted);
    if (ok) sess.right++; else sess.wrong.push(q.id);
    const last = sess.i === sess.q.length - 1;
    const verdict = ok
      ? (assisted ? 'Đúng rồi! 👍 Vì có dùng gợi ý nên từ này sẽ được ôn lại vào ngày mai.' : 'Chính xác! 🎉')
      : res === 'near' ? `Gần đúng rồi, bạn gõ “${esc(raw.trim())}” nhưng sai một chữ. Hãy chú ý chính tả nhé.`
      : res === 'skip' ? 'Không sao, hãy ghi nhớ từ này nhé.' : `Chưa đúng${raw.trim() ? ` (bạn gõ “${esc(raw.trim())}”)` : ''}. Hãy ghi nhớ nhé.`;
    $('#typeForm').hidden = true;
    $('#hintPat').textContent = hintPattern(w.word, 999);
    const fb = $('#fb');
    fb.hidden = false;
    fb.innerHTML = `
      <strong>${verdict}</strong>
      <div>Đáp án: <b lang="en">${esc(w.word)}</b> ${speakBtn(w.word, 'Nghe phát âm')} <span class="ipa">${esc(w.ipa)}</span> · ${esc(w.vi)}</div>
      ${w.alt && w.alt.length ? `<p class="muted" style="font-size:14px">Cách viết khác được chấp nhận: ${esc(w.alt.join(', '))}</p>` : ''}
      <p class="ex-en" lang="en">${esc(w.ex)} ${speakBtn(w.ex, 'Nghe câu ví dụ')}</p>
      <p class="ex-vi">${esc(w.exVi)}</p>
      <button type="button" class="btn" data-act="quiz-next">${last ? 'Xem kết quả' : 'Câu tiếp theo'}</button>`;
    fb.querySelector('.btn').focus({ preventScroll: false });
  }
  document.addEventListener('submit', e => {
    const f = e.target.closest && e.target.closest('form[data-quiz-form]');
    if (!f) return;
    e.preventDefault();
    typedSubmit(false);
  });

  function quizDone() {
    const n = sess.q.length, r = sess.right;
    const wrongHtml = sess.wrong.length
      ? `<div class="wrong-list"><strong>Từ cần chú ý:</strong>${sess.wrong.map(id => {
        const w = BY_ID.get(id);
        return `<div><b lang="en">${esc(w.word)}</b> ${esc(w.ipa)} · ${esc(w.vi)}</div>`;
      }).join('')}</div>` : '';
    view(`
      <div class="card flash">
        <div class="score">${r}/${n}</div>
        <p class="muted">${r === n ? 'Tuyệt vời, bạn nhớ hết rồi! 🌟' : (r / n >= 0.6 ? 'Làm tốt lắm, cố thêm chút nữa nhé!' : 'Đừng nản, những từ sai sẽ sớm quay lại để bạn ôn.')}</p>
        ${wrongHtml}
        <div class="stack" style="width:100%">
          <a class="btn btn-block" href="#/review">Ôn tập tiếp</a>
          <a class="btn btn-ghost btn-block" href="#/">Về tổng quan</a>
        </div>
      </div>`);
  }

  function reviewView() {
    const ids = dueQueue();
    const learned = learnedCount();
    const flagged = ids.filter(id => getW(id).flag).length;
    const practice = learned >= 4
      ? `<button type="button" class="btn btn-ghost btn-block" data-act="start-practice">Luyện thêm ngẫu nhiên 10 từ đã học</button>` : '';
    if (!ids.length) {
      view(`<h1 class="page-title">Ôn tập</h1>
        <div class="card empty stack"><div class="big">✅</div>
          <p><b>Không có từ nào đến hạn ôn.</b></p>
          <p class="muted">${learned ? 'Quay lại vào ngày mai nhé, hoặc luyện thêm bên dưới.' : 'Hãy học vài từ mới trước, rồi quay lại đây để ôn.'}</p>
          ${learned ? practice : '<a class="btn" href="#/learn">Đi học từ mới</a>'}
        </div>`);
      return;
    }
    view(`<h1 class="page-title">Ôn tập</h1>
      <div class="card stack">
        <p><b>${ids.length}</b> từ đến hạn ôn${flagged ? `, trong đó <b>${flagged}</b> từ bạn đánh dấu hoặc làm sai` : ''}.</p>
        <p class="muted">Ưu tiên các từ hay sai và lâu chưa ôn. Mỗi phiên tối đa ${QUIZ_SIZE} từ.</p>
        <button type="button" class="btn btn-block" data-act="start-review">Bắt đầu ôn ${Math.min(ids.length, QUIZ_SIZE)} từ</button>
        ${practice}
      </div>`);
  }

  /* ================= Lộ trình ================= */
  function planView() {
    const ls = lessons(), cur = currentLesson();
    const rest = TARGET - VOCAB.length;
    view(`
      <h1 class="page-title">Lộ trình học</h1>
      <p class="muted" style="margin-bottom:12px">Mục tiêu ${S.goal} từ/ngày. Có thể đổi trong phần Cài đặt.</p>
      <div class="stack">
        ${ls.map(l => {
          const done = lessonDone(l), full = done === l.ids.length, isCur = cur && cur.day === l.day;
          return `<a class="card day ${full ? 'done' : ''} ${isCur ? 'current' : ''}" href="#/learn/${l.day}" style="text-decoration:none;color:inherit">
            <div class="day-num">${full ? '✓' : l.day}</div>
            <div><div><b>Ngày ${l.day}</b> ${isCur ? '<span class="chip">Hôm nay</span>' : ''}</div>
              <div class="muted">${l.topics.map(t => `${topicIcon(t)} ${esc(topicName(t))}`).join(' · ')}</div></div>
            <div class="muted">${done}/${l.ids.length}</div>
          </a>`;
        }).join('')}
        ${rest > 0 ? `<p class="muted">Còn ${rest} từ chưa có trong kho dữ liệu (khoảng ${Math.ceil(rest / S.goal)} ngày học nữa). Xem README để bổ sung.</p>` : ''}
      </div>`);
  }

  /* ================= Danh sách từ: tìm kiếm & lọc ================= */
  const wf = { q: '', topic: 'all', status: 'all', limit: 30 };

  function wordCard(id, open) {
    const w = BY_ID.get(id), s = getW(id);
    const tags = `${statusTag(id)}<span class="tag">${topicIcon(w.topic)} ${esc(topicName(w.topic))}</span>`;
    const actions = !s.learned
      ? `<button type="button" class="btn btn-soft" data-act="w-learned" data-id="${id}">Đã biết từ này</button>`
      : `<button type="button" class="btn btn-warn" data-act="w-flag" data-id="${id}">${s.flag ? 'Bỏ đánh dấu cần ôn' : 'Cần ôn lại'}</button>
         <button type="button" class="btn btn-ghost" data-act="w-unlearn" data-id="${id}">Chưa học</button>`;
    return `<article class="card wcard" data-card="${id}">
      <div class="wc-top">
        <div>
          <h3 class="wc-word" lang="en">${esc(w.word)}</h3>
          <div class="wc-meta"><span class="ipa">${esc(w.ipa)}</span><span class="pos">${esc(posVi(w.pos))}</span></div>
        </div>
        <div class="wc-actions">${speakBtn(w.word, `Nghe phát âm từ ${w.word}`, 'icon-btn')}${favBtn(id)}</div>
      </div>
      <p class="wc-vi">${esc(w.vi)}</p>
      <div class="wc-tags">${tags}</div>
      <details class="wc-more" ${open ? 'open' : ''}>
        <summary>Ví dụ &amp; ghi chú</summary>
        <div class="body">
          <div class="example">
            <p class="ex-en" lang="en">${esc(w.ex)} ${speakBtn(w.ex, 'Nghe câu ví dụ')}</p>
            <p class="ex-vi">${esc(w.exVi)}</p>
          </div>
          ${w.note ? `<p class="note">💡 ${esc(w.note)}</p>` : ''}
          ${camLink(w)}
          <div class="row">${actions}</div>
        </div>
      </details>
    </article>`;
  }

  function filteredWords() {
    const q = norm(wf.q.trim());
    const t = dkey();
    return VOCAB.filter(w => {
      if (wf.topic !== 'all' && w.topic !== wf.topic) return false;
      const s = getW(w.id);
      if (wf.status === 'new' && s.learned) return false;
      if (wf.status === 'learned' && !s.learned) return false;
      if (wf.status === 'review' && !isDue(s, t)) return false;
      if (wf.status === 'fav' && !s.fav) return false;
      return !q || SEARCH.get(w.id).includes(q);
    });
  }
  function renderWordList() {
    const all = filteredWords();
    const shown = all.slice(0, wf.limit);
    $('#count').textContent = `${all.length} từ`;
    $('#list').innerHTML = shown.length
      ? shown.map(w => wordCard(w.id, false)).join('')
      : '<div class="card empty"><p>Không tìm thấy từ phù hợp.</p></div>';
    $('#moreWrap').innerHTML = all.length > shown.length
      ? `<button type="button" class="btn btn-ghost btn-block" data-act="more">Xem thêm (${all.length - shown.length} từ còn lại)</button>` : '';
  }
  function wordsView() {
    view(`
      <h1 class="page-title">Từ vựng</h1>
      <div class="filters">
        <input id="q" type="search" placeholder="Tìm từ tiếng Anh hoặc nghĩa tiếng Việt…" value="${esc(wf.q)}" autocomplete="off" aria-label="Tìm kiếm từ">
        <select id="fTopic" aria-label="Lọc theo chủ đề">
          <option value="all">Tất cả chủ đề</option>
          ${TOPICS.map(t => `<option value="${t.id}" ${wf.topic === t.id ? 'selected' : ''}>${t.icon} ${esc(t.name)}</option>`).join('')}
        </select>
        <select id="fStatus" aria-label="Lọc theo trạng thái">
          ${[['all', 'Mọi trạng thái'], ['new', 'Chưa học'], ['learned', 'Đã học'], ['review', 'Cần ôn'], ['fav', 'Yêu thích']]
            .map(([v, l]) => `<option value="${v}" ${wf.status === v ? 'selected' : ''}>${l}</option>`).join('')}
        </select>
      </div>
      <p id="count" class="muted" aria-live="polite"></p>
      <div id="list" class="wlist"></div>
      <div id="moreWrap" style="margin-top:12px"></div>`);
    let timer;
    $('#q').addEventListener('input', e => {
      clearTimeout(timer);
      timer = setTimeout(() => { wf.q = e.target.value; wf.limit = 30; renderWordList(); }, 150);
    });
    $('#fTopic').addEventListener('change', e => { wf.topic = e.target.value; wf.limit = 30; renderWordList(); });
    $('#fStatus').addEventListener('change', e => { wf.status = e.target.value; wf.limit = 30; renderWordList(); });
    renderWordList();
  }

  /* ================= Cài đặt ================= */
  function settingsView() {
    view(`
      <h1 class="page-title">Cài đặt</h1>
      <div class="stack">
        <section class="card stack">
          <h2 style="font-size:18px">Mục tiêu mỗi ngày</h2>
          <div class="seg" role="group" aria-label="Chọn mục tiêu mỗi ngày">
            ${GOALS.map(g => `<button type="button" data-act="goal" data-goal="${g}" class="${S.goal === g ? 'on' : ''}" aria-pressed="${S.goal === g}">${g}</button>`).join('')}
          </div>
          <label class="muted" for="goalCustom">Hoặc nhập số từ khác (10–100):</label>
          <input id="goalCustom" class="field" type="number" inputmode="numeric" min="10" max="100" step="1" value="${S.goal}">
          <p class="muted">Mặc định 10 từ/ngày. Đổi mục tiêu sẽ chia lại các bài học theo ngày, tiến độ từng từ vẫn được giữ nguyên.</p>
        </section>

        <section class="card stack">
          <h2 style="font-size:18px">Kiểu ôn tập</h2>
          <div class="seg" role="group" aria-label="Chọn kiểu ôn tập">
            <button type="button" data-act="mode" data-mode="type" class="${prefs.mode === 'type' ? 'on' : ''}" aria-pressed="${prefs.mode === 'type'}">Điền từ theo gợi ý</button>
            <button type="button" data-act="mode" data-mode="choice" class="${prefs.mode === 'choice' ? 'on' : ''}" aria-pressed="${prefs.mode === 'choice'}">Trắc nghiệm</button>
          </div>
          <p class="muted">Điền từ: xem nghĩa tiếng Việt và chữ cái đầu, gõ lại từ tiếng Anh. Bấm “Gợi ý thêm” để lộ thêm chữ cái hoặc “Nghe gợi ý”. Trả lời đúng nhưng có dùng gợi ý thì từ sẽ được ôn lại sớm hơn.</p>
        </section>

        <section class="card stack">
          <h2 style="font-size:18px">Phát âm</h2>
          <label class="switch"><input type="checkbox" id="real" ${prefs.real ? 'checked' : ''}> Ưu tiên bản ghi âm thật của người đọc (Anh-Anh, cần mạng)</label>
          <label class="lbl" for="voiceSel">Giọng đọc dự phòng của thiết bị</label>
          <select id="voiceSel" class="field">
            <option value="">Tự động chọn giọng Anh-Anh tốt nhất (khuyên dùng)</option>
            ${englishVoices().map(v => `<option value="${esc(v.voiceURI || v.name)}" ${prefs.voice && (prefs.voice === v.voiceURI || prefs.voice === v.name) ? 'selected' : ''}>${esc(v.name)} (${esc(v.lang)})</option>`).join('')}
          </select>
          <label class="switch"><input type="checkbox" id="slow" ${S.slow ? 'checked' : ''}> Đọc chậm hơn</label>
          <button type="button" class="btn btn-soft" data-act="speak" data-text="Hello! Let's learn English together.">🔊 Nghe thử giọng đọc</button>
          <p class="muted">Từ đơn lẻ sẽ phát bản ghi âm người thật nếu tìm được bản Anh-Anh (nguồn: dictionaryapi.dev, mỗi lần phát sẽ gửi từ đó tới dịch vụ này). Nếu không có, câu ví dụ hoặc khi tắt tùy chọn này, website dùng giọng đọc của thiết bị.</p>
          <details class="wc-more"><summary>Muốn giọng thiết bị tự nhiên hơn?</summary><div class="body muted">
            <p><b>Windows (Edge):</b> dùng trình duyệt Microsoft Edge, giọng “Microsoft Sonia/Ryan Online (Natural) – English (United Kingdom)” rất tự nhiên và sẽ hiện trong danh sách trên.</p>
            <p><b>iPhone/iPad:</b> Cài đặt → Trợ năng → Nội dung được đọc → Giọng nói → Tiếng Anh (Anh), tải giọng “Daniel” hoặc “Serena” bản Nâng cao.</p>
            <p><b>Android:</b> Cài đặt → Quản lý chung → Chuyển văn bản thành giọng nói, chọn Google, ngôn ngữ English (United Kingdom) và tải dữ liệu giọng.</p>
            <p><b>Mac:</b> Cài đặt hệ thống → Trợ năng → Nội dung được đọc → Giọng nói hệ thống, tải giọng Anh (Anh) bản Nâng cao.</p></div></details>
        </section>

        <section class="card stack">
          <h2 style="font-size:18px">Sao lưu tiến độ</h2>
          <p class="muted">Tiến độ lưu ngay trên trình duyệt này. Hãy xuất file để sao lưu hoặc chuyển sang thiết bị khác.</p>
          <div class="row">
            <button type="button" class="btn btn-soft" data-act="export">Xuất tiến độ</button>
            <button type="button" class="btn btn-ghost" data-act="import">Nhập tiến độ</button>
            <input id="importFile" type="file" accept="application/json,.json" hidden>
          </div>
        </section>

        <section class="card stack">
          <h2 style="font-size:18px">Xóa dữ liệu</h2>
          <button type="button" class="btn btn-danger" data-act="reset">Xóa toàn bộ tiến độ</button>
        </section>
      </div>`);
    $('#goalCustom').addEventListener('change', e => {
      const v = Math.round(Number(e.target.value));
      if (v >= 10 && v <= 100) { S.goal = v; save(); toast(`Đã đặt mục tiêu ${v} từ/ngày.`); settingsView(); }
      else { toast('Hãy nhập số từ 10 đến 100.'); e.target.value = S.goal; }
    });
    $('#slow').addEventListener('change', e => { S.slow = e.target.checked; save(); });
    $('#real').addEventListener('change', e => { prefs.real = e.target.checked; savePrefs(); });
    $('#voiceSel').addEventListener('change', e => { prefs.voice = e.target.value; savePrefs(); stopSpeech(); speakTts("Hello! Let's learn English together."); });
  }

  function exportProgress() {
    const payload = { app: 'vocab1000', version: 1, exportedAt: new Date().toISOString(), data: S };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `tien-do-tu-vung-${dkey()}.json`;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 1500);
  }
  function importProgress(file) {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const obj = JSON.parse(reader.result);
        if (!obj || obj.app !== 'vocab1000' || !obj.data || typeof obj.data.words !== 'object') throw new Error('bad');
        if (!confirm('Nhập tiến độ sẽ thay thế tiến độ hiện tại trên thiết bị này. Tiếp tục?')) return;
        S = sanitize(obj.data);
        if (Cloud.session()) S.owner = Cloud.session().user.id;
        save();
        syncNow({ force: true, quiet: true });
        toast('Đã nhập tiến độ.');
        route();
      } catch (e) { toast('File không hợp lệ. Hãy chọn file đã xuất từ website này.'); }
    };
    reader.readAsText(file);
  }

  /* ================= Xử lý sự kiện ================= */
  const actions = {
    speak: el => speak(el.dataset.text),
    fav: el => {
      const id = el.dataset.id, on = !getW(id).fav;
      setW(id, { fav: on });
      document.querySelectorAll(`.fav[data-id="${id}"]`).forEach(b => { b.classList.toggle('on', on); b.setAttribute('aria-pressed', String(on)); });
    },
    'learn-next': el => {
      markLearned(sess.ids[sess.i], el.dataset.review === '1');
      sess.i++;
      if (sess.i >= sess.ids.length) learnDone(); else renderLearn();
    },
    'learn-prev': () => { if (sess.i > 0) { sess.i--; renderLearn(); } },
    'quiz-lesson': () => {
      const ids = sess.lessonIds.filter(id => getW(id).learned);
      startQuiz(ids.slice(0, QUIZ_SIZE), `Kiểm tra ngày ${sess.day}`, '#/');
    },
    'start-review': () => startQuiz(dueQueue().slice(0, QUIZ_SIZE), 'Ôn tập', '#/review'),
    'start-practice': () => {
      const ids = VOCAB.filter(w => getW(w.id).learned).map(w => w.id);
      startQuiz(shuffle(ids).slice(0, 10), 'Luyện thêm', '#/review');
    },
    'quiz-pick': el => quizPick(el),
    'type-hint': () => typedHint(),
    'type-listen': () => typedListen(),
    'type-skip': () => typedSubmit(true),
    mode: el => { prefs.mode = el.dataset.mode === 'choice' ? 'choice' : 'type'; savePrefs(); settingsView(); },
    'quiz-next': () => { sess.i++; if (sess.i >= sess.q.length) quizDone(); else renderQuiz(); },
    more: () => { wf.limit += 30; renderWordList(); },
    'w-learned': el => { markLearned(el.dataset.id, false); refreshCard(el); },
    'w-flag': el => { const id = el.dataset.id; setW(id, { flag: !getW(id).flag, due: dkey() }); refreshCard(el); },
    'w-unlearn': el => { unlearn(el.dataset.id); refreshCard(el); },
    goal: el => { S.goal = Number(el.dataset.goal); save(); toast(`Đã đặt mục tiêu ${S.goal} từ/ngày.`); settingsView(); },
    export: () => exportProgress(),
    import: () => $('#importFile').click(),
    reset: () => {
      if (confirm('Xóa toàn bộ tiến độ học trên thiết bị này? Việc này không thể hoàn tác.')) {
        S = defaults();
        if (Cloud.session()) S.owner = Cloud.session().user.id;
        save();
        syncNow({ force: true, quiet: true });
        toast('Đã xóa tiến độ.'); route();
      }
    }
  };
  function refreshCard(el) {
    const card = el.closest('.wcard');
    if (!card) return;
    const open = card.querySelector('details').open;
    card.outerHTML = wordCard(card.dataset.card, open);
    updateNav(currentRouteName());
  }

  document.addEventListener('click', e => {
    const filterLink = e.target.closest('[data-filter]');
    if (filterLink) { wf.status = filterLink.dataset.filter; wf.topic = 'all'; wf.q = ''; wf.limit = 30; }
    const el = e.target.closest('[data-act]');
    if (!el) return;
    const fn = actions[el.dataset.act];
    if (fn) fn(el);
  });
  document.addEventListener('change', e => {
    if (e.target.id === 'importFile' && e.target.files[0]) { importProgress(e.target.files[0]); e.target.value = ''; }
  });

  /* ================= Đồng bộ với máy chủ ================= */
  const sync = { state: 'off', at: 0, msg: '' };
  let syncing = false, again = false, syncTimer = null;
  const sleep = ms => new Promise(r => setTimeout(r, ms));

  const displayName = () => {
    const s = Cloud.session();
    return s ? (s.user.name || (s.user.email || '').split('@')[0] || 'Người học') : '';
  };
  function profileStats() {
    let week = 0, d = dkey();
    for (let i = 0; i < 7; i++) { week += (S.log[d] || EMPTY).learned || 0; d = addDays(d, -1); }
    return { name: displayName().slice(0, 40), learned: learnedCount(), streak: streak(), week };
  }
  function scheduleSync() {
    if (!Cloud.configured || !Cloud.session()) return;
    clearTimeout(syncTimer);
    syncTimer = setTimeout(() => { syncNow({ quiet: true }); }, 2500);
  }
  function syncText() {
    if (sync.state === 'syncing') return 'Đang đồng bộ…';
    if (sync.state === 'error') return 'Đồng bộ lỗi: ' + sync.msg;
    if (sync.at) return 'Đã đồng bộ lúc ' + new Date(sync.at).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' });
    return 'Chưa đồng bộ';
  }
  function refreshSyncUi() { const el = $('#syncStatus'); if (el) el.textContent = syncText(); }

  /* opts.force: đẩy dữ liệu trên máy lên, không gộp (dùng sau khi nhập/xóa tiến độ). */
  async function syncNow(opts = {}) {
    if (!Cloud.configured || !Cloud.session()) return false;
    if (syncing) {
      if (!opts.force) { again = true; return false; }
      while (syncing) await sleep(100);
    }
    syncing = true; sync.state = 'syncing'; refreshSyncUi();
    try {
      if (!opts.force) {
        const r = await Cloud.fetchProgress();
        if (r && r.data) { const m = Cloud.merge(S, r.data); m.owner = S.owner; S = sanitize(m); persist(); }
      }
      await Cloud.pushProgress(S);
      await Cloud.pushProfile(profileStats());
      sync.state = 'ok'; sync.at = Date.now(); sync.msg = '';
      return true;
    } catch (e) {
      sync.state = 'error'; sync.msg = e.message || 'không rõ nguyên nhân';
      if (!Cloud.session()) { updateHeader(); toast('Phiên đăng nhập đã hết hạn, hãy đăng nhập lại.'); }
      else if (!opts.quiet) toast(sync.msg);
      return false;
    } finally {
      syncing = false; refreshSyncUi();
      if (again) { again = false; scheduleSync(); }
    }
  }

  /* Sau khi đăng nhập: tách tiến độ của tài khoản khác trên cùng thiết bị, rồi gộp với máy chủ. */
  async function afterSignIn() {
    const uid = Cloud.session().user.id;
    if (S.owner && S.owner !== uid) {
      if (learnedCount() > 0 && !confirm('Tiến độ đang lưu trên thiết bị này thuộc về một tài khoản khác. Nếu tiếp tục, thiết bị sẽ chuyển sang tiến độ của tài khoản bạn vừa đăng nhập. Tiếp tục?')) {
        await Cloud.signOut(); updateHeader();
        throw new Error('Đã hủy đăng nhập.');
      }
      S = defaults();
    }
    S.owner = uid; persist();
    updateHeader();
    await syncNow({ quiet: true });
  }

  /* ================= Tài khoản ================= */
  let authTab = 'in', recovery = false, routeToken = 0;

  function setupCard() {
    return `<div class="card stack">
      <h2 style="font-size:18px">Chưa bật tài khoản trực tuyến</h2>
      <p>Website đang chạy ở chế độ cá nhân: tiến độ chỉ lưu trên trình duyệt này.</p>
      <p class="muted">Để bạn bè cùng đăng nhập, đồng bộ nhiều thiết bị và xem bảng xếp hạng, người quản trị cần tạo project Supabase và điền hai giá trị vào <code>js/config.js</code>. Xem README, mục “Bật tài khoản và bảng xếp hạng”.</p>
    </div>`;
  }
  const formMsg = (t, ok) => { const m = $('#formMsg'); if (m) { m.textContent = t; m.className = 'form-msg' + (ok ? ' ok' : ''); } };
  const field = (name, label, type, extra = '') =>
    `<label class="lbl" for="f-${name}">${label}</label><input class="field" id="f-${name}" name="${name}" type="${type}" ${extra}>`;

  /* ---- Đăng nhập bằng tên (hồ sơ trên thiết bị) ---- */
  function statsOf(d) {
    let learned = 0, week = 0, k = dkey();
    for (const w of VOCAB) if (d.words[w.id] && d.words[w.id].learned) learned++;
    for (let i = 0; i < 7; i++) { week += (d.log[k] || EMPTY).learned || 0; k = addDays(k, -1); }
    const act = x => { const l = d.log[x]; return !!l && ((l.learned || 0) + (l.reviewed || 0)) > 0; };
    let st = 0; k = dkey(); if (!act(k)) k = addDays(k, -1);
    while (act(k)) { st++; k = addDays(k, -1); }
    return { learned, week, streak: st };
  }
  function switchProfile(id) {
    PF.current = id; savePF();
    S = loadKey(curKey());
    updateHeader();
  }
  function localAccountView() {
    const cur = curProfile();
    const guest = statsOf(loadKey(STORAGE_KEY));
    const rows = PF.list.map(p => {
      const st = statsOf(loadKey(keyFor(p.id))), me = p.id === PF.current;
      return `<div class="prof-row ${me ? 'me' : ''}">
        <div class="avatar sm" aria-hidden="true">${esc(p.name.charAt(0).toUpperCase())}</div>
        <div><b>${esc(p.name)}</b>${me ? ' <span class="chip">Đang dùng</span>' : ''}<div class="muted" style="font-size:13px">${st.learned} từ đã học · 🔥 ${st.streak} ngày</div></div>
        <div class="row" style="flex-wrap:nowrap">
          ${me ? '' : `<button type="button" class="btn btn-soft" data-act="lp-switch" data-id="${esc(p.id)}">Chọn</button>`}
          <button type="button" class="icon-btn sm" data-act="lp-delete" data-id="${esc(p.id)}" aria-label="Xóa hồ sơ ${esc(p.name)}">🗑️</button>
        </div></div>`;
    }).join('');
    view(`<h1 class="page-title">Hồ sơ người học</h1>
      <div class="stack">
        <section class="card stack">
          ${cur
            ? `<div class="row"><div class="avatar" aria-hidden="true">${esc(cur.name.charAt(0).toUpperCase())}</div><div><b>Xin chào, ${esc(cur.name)}!</b><div class="muted">Bạn đang học với hồ sơ này.</div></div></div>
               <button type="button" class="btn btn-ghost" data-act="lp-logout">Đăng xuất (đổi người dùng)</button>`
            : `<p><b>Bạn đang học ở chế độ khách.</b></p><p class="muted">Tạo hồ sơ để mỗi người dùng chung máy có tiến độ và chuỗi ngày học riêng.</p>`}
        </section>
        ${rows ? `<section class="card"><h2 style="font-size:18px;margin-bottom:6px">Hồ sơ trên máy này</h2>${rows}</section>` : ''}
        <section class="card"><h2 style="font-size:18px;margin-bottom:8px">Tạo hồ sơ mới</h2>
          <form data-lp-form class="stack" novalidate>
            ${field('name', 'Tên của bạn', 'text', 'maxlength="30" autocomplete="nickname" required')}
            ${guest.learned > 0 ? `<label class="switch"><input type="checkbox" name="keep" checked> Chuyển tiến độ chế độ khách hiện có (${guest.learned} từ đã học) vào hồ sơ này</label>` : ''}
            <p id="formMsg" class="form-msg" role="alert"></p>
            <button class="btn btn-block" type="submit">Tạo hồ sơ và đăng nhập</button>
          </form></section>
        <p class="muted" style="font-size:13px">Hồ sơ lưu ngay trên trình duyệt này, không có mật khẩu và không đồng bộ sang thiết bị khác, nên ai dùng chung máy cũng chọn được. Muốn có mật khẩu, đồng bộ nhiều thiết bị và xếp hạng cùng bạn bè, hãy bật tài khoản trực tuyến (xem README, mục Supabase).</p>
      </div>`);
  }
  document.addEventListener('submit', e => {
    if (Cloud.configured) return;                 // chế độ tài khoản trực tuyến dùng form riêng
    const f = e.target.closest && e.target.closest('form[data-lp-form]');
    if (!f) return;
    e.preventDefault();
    const say = t => { const m = $('#formMsg'); if (m) { m.textContent = t; m.className = 'form-msg'; } };
    const name = String(f.elements.name ? f.elements.name.value : '').replace(/\s+/g, ' ').trim();
    if (!name) { say('Hãy nhập tên của bạn.'); return; }
    if (name.length > 30) { say('Tên tối đa 30 ký tự.'); return; }
    if (PF.list.some(p => p.name.toLowerCase() === name.toLowerCase())) { say('Tên này đã có trên máy. Hãy chọn tên khác hoặc chọn hồ sơ đã có.'); return; }
    const keep = !!(f.elements.keep && f.elements.keep.checked);
    const id = 'p' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
    const carry = keep ? loadKey(STORAGE_KEY) : defaults();
    PF.list.push({ id, name }); PF.current = id; savePF();
    S = carry; persist();
    if (keep) { try { localStorage.removeItem(STORAGE_KEY); } catch (err) { /* bỏ qua */ } }
    updateHeader(); toast(`Xin chào, ${name}!`); nav('#/');
  });

  function localRankView() {
    const head = `<h1 class="page-title">Xếp hạng</h1>
      <div class="seg" role="group" aria-label="Kiểu xếp hạng" style="margin-bottom:12px">
        <button type="button" data-act="rank-by" data-by="week" class="${rankBy === 'week' ? 'on' : ''}" aria-pressed="${rankBy === 'week'}">Tuần này</button>
        <button type="button" data-act="rank-by" data-by="all" class="${rankBy === 'all' ? 'on' : ''}" aria-pressed="${rankBy === 'all'}">Tổng số từ</button></div>`;
    if (!PF.list.length) {
      view(head + '<div class="card empty stack"><div class="big">🏆</div><p>Tạo hồ sơ để xếp hạng giữa những người dùng chung máy này.</p><a class="btn" href="#/account">Tạo hồ sơ</a></div>');
      return;
    }
    const rows = PF.list.map(p => Object.assign({ id: p.id, name: p.name }, statsOf(loadKey(keyFor(p.id)))))
      .sort((a, b) => rankBy === 'week' ? (b.week - a.week || b.learned - a.learned) : (b.learned - a.learned || b.streak - a.streak));
    const list = rows.map((r, i) => `<li class="rank-row ${r.id === PF.current ? 'me' : ''}">
        <span class="rank-n">${i < 3 ? ['🥇', '🥈', '🥉'][i] : i + 1}</span>
        <span class="rank-name">${esc(r.name)}${r.id === PF.current ? ' <span class="chip">Bạn</span>' : ''}<small class="muted">🔥 ${r.streak} ngày</small></span>
        <b>${rankBy === 'week' ? r.week : r.learned}<small class="muted"> từ</small></b></li>`).join('');
    view(head + `<ol class="card rank-list">${list}</ol>
      <p class="muted" style="margin-top:10px;font-size:13px">Đây là xếp hạng giữa các hồ sơ trên thiết bị này. Muốn xếp hạng cùng bạn bè ở thiết bị khác, hãy bật tài khoản trực tuyến (xem README).</p>`);
  }

  function accountView() {
    if (!Cloud.configured) { localAccountView(); return; }
    const s = Cloud.session();
    if (recovery && s) {
      view(`<h1 class="page-title">Đặt mật khẩu mới</h1><div class="card"><form data-form="newpass" class="stack" novalidate>
        ${field('password', 'Mật khẩu mới (ít nhất 8 ký tự)', 'password', 'autocomplete="new-password" minlength="8" required')}
        <p id="formMsg" class="form-msg" role="alert"></p>
        <button class="btn btn-block" type="submit">Lưu mật khẩu</button></form></div>`);
      return;
    }
    if (!s) {
      const forgot = authTab === 'forgot', up = authTab === 'up';
      view(`<h1 class="page-title">Tài khoản</h1>
        <div class="card stack">
          <p class="muted">Đăng nhập để đồng bộ tiến độ giữa các thiết bị và xem bảng xếp hạng cùng bạn bè.</p>
          ${forgot ? '' : `<div class="seg" role="group" aria-label="Chọn đăng nhập hoặc đăng ký">
            <button type="button" data-act="auth-tab" data-tab="in" class="${!up ? 'on' : ''}" aria-pressed="${!up}">Đăng nhập</button>
            <button type="button" data-act="auth-tab" data-tab="up" class="${up ? 'on' : ''}" aria-pressed="${up}">Đăng ký</button></div>`}
          <form data-form="${forgot ? 'forgot' : up ? 'signup' : 'signin'}" class="stack" novalidate>
            ${up ? field('name', 'Tên hiển thị (hiện trên bảng xếp hạng)', 'text', 'maxlength="40" autocomplete="nickname" required') : ''}
            ${field('email', 'Email', 'email', 'autocomplete="email" inputmode="email" required')}
            ${forgot ? '' : field('password', up ? 'Mật khẩu (ít nhất 8 ký tự)' : 'Mật khẩu', 'password', `autocomplete="${up ? 'new-password' : 'current-password'}" required`)}
            <p id="formMsg" class="form-msg" role="alert"></p>
            <button class="btn btn-block" type="submit">${forgot ? 'Gửi email đặt lại mật khẩu' : up ? 'Tạo tài khoản' : 'Đăng nhập'}</button>
          </form>
          ${forgot ? '<button type="button" class="link-btn" data-act="auth-tab" data-tab="in">← Quay lại đăng nhập</button>'
            : (!up ? '<button type="button" class="link-btn" data-act="auth-tab" data-tab="forgot">Quên mật khẩu?</button>' : '')}
          <p class="muted" style="font-size:13px">Tiến độ học hiện có trên thiết bị này sẽ được gộp vào tài khoản. Email không bao giờ hiện cho người khác.</p>
        </div>`);
      return;
    }
    const st = profileStats();
    view(`<h1 class="page-title">Tài khoản</h1>
      <div class="stack">
        <section class="card stack">
          <div class="row"><div class="avatar" aria-hidden="true">${esc((displayName() || '?').charAt(0).toUpperCase())}</div>
            <div><b>${esc(displayName())}</b><div class="muted">${esc(s.user.email)}</div></div></div>
          <p class="muted">${st.learned} từ đã học · 🔥 ${st.streak} ngày · ${st.week} từ trong 7 ngày qua</p>
          <p id="syncStatus" class="muted" aria-live="polite">${esc(syncText())}</p>
          <div class="row"><button type="button" class="btn btn-soft" data-act="sync-now">Đồng bộ ngay</button><a class="btn btn-ghost" href="#/rank">Xem xếp hạng</a></div>
        </section>
        <section class="card"><form data-form="name" class="stack" novalidate>
          ${field('name', 'Tên hiển thị', 'text', `maxlength="40" value="${esc(s.user.name)}" required`)}
          <p id="formMsg" class="form-msg" role="alert"></p>
          <button class="btn btn-soft" type="submit">Lưu tên</button></form></section>
        <section class="card"><form data-form="newpass" class="stack" novalidate>
          ${field('password', 'Đổi mật khẩu (ít nhất 8 ký tự)', 'password', 'autocomplete="new-password" minlength="8" required')}
          <p id="formMsg2" class="form-msg" role="alert"></p>
          <button class="btn btn-soft" type="submit">Đổi mật khẩu</button></form></section>
        <section class="card"><button type="button" class="btn btn-ghost btn-block" data-act="signout">Đăng xuất</button>
          <p class="muted" style="margin-top:8px;font-size:13px">Đăng xuất không xóa tiến độ trên thiết bị này.</p></section>
      </div>`);
  }

  const nav = h => { if (location.hash === h) route(); else location.hash = h; };
  const validEmail = e => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e);

  document.addEventListener('submit', async e => {
    const f = e.target.closest('form[data-form]');
    if (!f) return;
    e.preventDefault();
    const kind = f.dataset.form, val = n => (f.elements[n] ? f.elements[n].value : '').trim();
    const raw = n => (f.elements[n] ? f.elements[n].value : '');
    const msgId = kind === 'newpass' && $('#formMsg2') ? '#formMsg2' : '#formMsg';
    const say = (t, ok) => { const m = $(msgId); if (m) { m.textContent = t; m.className = 'form-msg' + (ok ? ' ok' : ''); } };
    const btn = f.querySelector('[type=submit]');
    const email = val('email');
    say('');
    try {
      if ((kind === 'signin' || kind === 'signup' || kind === 'forgot') && !validEmail(email)) throw new Error('Hãy nhập email hợp lệ.');
      if (kind === 'signup' && !val('name')) throw new Error('Hãy nhập tên hiển thị.');
      if ((kind === 'signup' || kind === 'newpass') && raw('password').length < 8) throw new Error('Mật khẩu cần ít nhất 8 ký tự.');
      if (kind === 'signin' && !raw('password')) throw new Error('Hãy nhập mật khẩu.');
      if (kind === 'name' && !val('name')) throw new Error('Tên hiển thị không được để trống.');
      btn.disabled = true;
      if (kind === 'signin') {
        await Cloud.signIn(email, raw('password'));
        await afterSignIn(); toast('Đăng nhập thành công.'); nav('#/');
      } else if (kind === 'signup') {
        const r = await Cloud.signUp(email, raw('password'), val('name'));
        if (r.needsConfirm) { say(`Đã gửi email xác nhận tới ${email}. Hãy mở email, bấm liên kết rồi quay lại đăng nhập.`, true); f.reset(); }
        else { await afterSignIn(); toast('Đã tạo tài khoản.'); nav('#/'); }
      } else if (kind === 'forgot') {
        await Cloud.recover(email);
        say('Nếu email này đã đăng ký, bạn sẽ nhận được liên kết đặt lại mật khẩu trong ít phút.', true);
      } else if (kind === 'newpass') {
        await Cloud.updatePassword(raw('password'));
        recovery = false; f.reset(); say('Đã cập nhật mật khẩu.', true);
        if (msgId === '#formMsg') setTimeout(() => nav('#/'), 800);
      } else if (kind === 'name') {
        await Cloud.setName(val('name')); updateHeader(); syncNow({ quiet: true }); say('Đã lưu tên hiển thị.', true);
      }
    } catch (err) { say(err.message || 'Có lỗi xảy ra.'); }
    finally { if (btn) btn.disabled = false; }
  });

  /* ================= Bảng xếp hạng ================= */
  let rankBy = 'week';
  async function rankView() {
    if (!Cloud.configured) { localRankView(); return; }
    if (!Cloud.session()) {
      view(`<h1 class="page-title">Xếp hạng</h1><div class="card empty stack"><div class="big">🏆</div>
        <p>Đăng nhập để xem bảng xếp hạng cùng bạn bè.</p><a class="btn" href="#/account">Đăng nhập / Đăng ký</a></div>`);
      return;
    }
    const tok = routeToken;
    const head = `<h1 class="page-title">Xếp hạng</h1>
      <div class="seg" role="group" aria-label="Kiểu xếp hạng" style="margin-bottom:12px">
        <button type="button" data-act="rank-by" data-by="week" class="${rankBy === 'week' ? 'on' : ''}" aria-pressed="${rankBy === 'week'}">Tuần này</button>
        <button type="button" data-act="rank-by" data-by="all" class="${rankBy === 'all' ? 'on' : ''}" aria-pressed="${rankBy === 'all'}">Tổng số từ</button></div>`;
    view(head + '<div class="card empty"><p class="muted">Đang tải bảng xếp hạng…</p></div>');
    try {
      await syncNow({ quiet: true });             // đẩy số liệu mới nhất của bạn trước khi xem
      const rows = await Cloud.leaderboard(rankBy);
      if (tok !== routeToken) return;
      const me = Cloud.session() && Cloud.session().user.id;
      const val = r => rankBy === 'week' ? r.week_learned : r.learned;
      const list = rows.map((r, i) => `<li class="rank-row ${r.id === me ? 'me' : ''}">
          <span class="rank-n">${i < 3 ? ['🥇', '🥈', '🥉'][i] : i + 1}</span>
          <span class="rank-name">${esc(r.display_name)}${r.id === me ? ' <span class="chip">Bạn</span>' : ''}<small class="muted">🔥 ${r.streak} ngày</small></span>
          <b>${val(r)}<small class="muted"> từ</small></b></li>`).join('');
      view(head + (rows.length ? `<ol class="card rank-list">${list}</ol>` : '<div class="card empty"><p>Chưa có ai trên bảng xếp hạng.</p></div>') +
        `<p class="muted" style="margin-top:10px;font-size:13px">“Tuần này” tính số từ mới học trong 7 ngày gần nhất, cập nhật mỗi khi mỗi người đồng bộ. Tên hiển thị hiện với mọi người đã đăng nhập, email thì không.</p>
         <button type="button" class="btn btn-ghost btn-block" style="margin-top:10px" data-act="rank-by" data-by="${rankBy}">Làm mới</button>`);
    } catch (err) {
      if (tok !== routeToken) return;
      view(head + `<div class="card empty stack"><p>${esc(err.message)}</p><button type="button" class="btn" data-act="rank-by" data-by="${rankBy}">Thử lại</button></div>`);
    }
  }

  Object.assign(actions, {
    'lp-switch': el => { const p = PF.list.find(x => x.id === el.dataset.id); if (!p) return; switchProfile(p.id); toast(`Xin chào, ${p.name}!`); nav('#/'); },
    'lp-logout': () => { switchProfile(''); toast('Đã đăng xuất. Bạn đang ở chế độ khách.'); nav('#/'); },
    'lp-delete': el => {
      const p = PF.list.find(x => x.id === el.dataset.id); if (!p) return;
      if (!confirm(`Xóa hồ sơ “${p.name}” và toàn bộ tiến độ của hồ sơ này khỏi máy? Việc này không thể hoàn tác.`)) return;
      PF.list = PF.list.filter(x => x.id !== p.id);
      try { localStorage.removeItem(keyFor(p.id)); } catch (e) { /* bỏ qua */ }
      if (PF.current === p.id) { PF.current = ''; S = loadKey(curKey()); }
      savePF(); updateHeader(); toast('Đã xóa hồ sơ.'); accountView();
    },
    'auth-tab': el => { authTab = el.dataset.tab; accountView(); },
    'sync-now': async () => { const ok = await syncNow(); if (ok) toast('Đã đồng bộ.'); },
    signout: async () => { clearTimeout(syncTimer); await Cloud.signOut(); sync.state = 'off'; sync.at = 0; updateHeader(); toast('Đã đăng xuất.'); nav('#/'); },
    'rank-by': el => { rankBy = el.dataset.by === 'all' ? 'all' : 'week'; rankView(); }
  });

  /* ================= Router ================= */
  const routes = {
    '': dashboardView, learn: learnView, review: reviewView, words: wordsView,
    plan: planView, settings: settingsView, account: accountView, rank: rankView
  };
  const currentRouteName = () => location.hash.replace(/^#\/?/, '').split('/')[0];
  function route() {
    const [name, ...args] = location.hash.replace(/^#\/?/, '').split('/');
    stopSpeech();
    sess = null; routeToken++;
    (routes[name] || dashboardView)(...args);
    updateNav(routes[name] ? name : '');
  }

  async function init() {
    buildNav();
    if (!VOCAB.length) {
      app.innerHTML = '<div class="card empty"><p>Không tải được dữ liệu từ vựng (data/vocab.js).</p></div>';
      return;
    }
    window.addEventListener('hashchange', route);
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible' && Cloud.session() && Date.now() - sync.at > 60000) syncNow({ quiet: true });
    });
    if (Cloud.configured) {
      const r = await Cloud.consumeAuthHash();          // liên kết từ email: xác nhận đăng ký / đặt lại mật khẩu
      if (r && r.error) { route(); toast(r.error); }
      else if (r) {
        recovery = r.type === 'recovery';
        try { await afterSignIn(); } catch (e) { toast(e.message); }
        nav('#/account');
        if (!recovery) toast('Đã xác nhận email, chào mừng bạn!');
        return;
      }
    }
    route();
    if (Cloud.session()) {
      updateHeader();
      await syncNow({ quiet: true });
      if (!sess && ['', 'plan', 'review'].includes(currentRouteName())) route();
    }
  }
  init();
})();
