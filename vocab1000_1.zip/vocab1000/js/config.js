/* Cấu hình tài khoản & bảng xếp hạng (Supabase).
 *
 * Để TRỐNG thì website vẫn chạy bình thường ở chế độ cá nhân (chỉ lưu trên trình duyệt),
 * các mục Tài khoản và Xếp hạng sẽ hiện hướng dẫn thiết lập.
 *
 * Cách điền: xem README, mục "Bật tài khoản và bảng xếp hạng".
 *   url     : Project URL, dạng https://abcdxyz.supabase.co
 *   anonKey : khóa công khai của project (mục "anon public" hoặc "publishable" trong Project Settings → API)
 *
 * CHỈ dùng khóa công khai. TUYỆT ĐỐI KHÔNG dán khóa "service_role" hoặc "secret" vào file này,
 * vì file này được gửi cho mọi người truy cập website.
 */
window.CLOUD_CONFIG = {
  url: "",
  anonKey: ""
};
