#!/usr/bin/env node
/* Chuyển file CSV thành các dòng JavaScript để dán vào mảng VOCAB trong data/vocab.js.
 *
 * Cách dùng:  node tools/csv-to-vocab.mjs tu-moi.csv > tu-moi.txt
 *
 * CSV cần dòng tiêu đề (UTF-8) với các cột:
 *   id,topic,word,ipa,pos,vi,ex,exVi,note,alt
 * Cột note và alt có thể để trống. Cột alt: các cách viết khác, ngăn cách bằng dấu | (ví dụ practice|practise). Giá trị chứa dấu phẩy cần đặt trong dấu ngoặc kép "…".
 * Sau khi dán vào data/vocab.js, chạy:  node tools/validate-data.mjs
 */
import fs from 'node:fs';

const file = process.argv[2];
if (!file) { console.error('Cách dùng: node tools/csv-to-vocab.mjs <file.csv>'); process.exit(1); }

function parseCsv(text) {
  const rows = []; let row = [], cell = '', q = false;
  text = text.replace(/^﻿/, '');
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) {
      if (c === '"' && text[i + 1] === '"') { cell += '"'; i++; }
      else if (c === '"') q = false;
      else cell += c;
    } else if (c === '"') q = true;
    else if (c === ',') { row.push(cell); cell = ''; }
    else if (c === '\n' || c === '\r') {
      if (c === '\r' && text[i + 1] === '\n') i++;
      row.push(cell); cell = '';
      if (row.some(x => x.trim() !== '')) rows.push(row);
      row = [];
    } else cell += c;
  }
  row.push(cell);
  if (row.some(x => x.trim() !== '')) rows.push(row);
  return rows;
}

const rows = parseCsv(fs.readFileSync(file, 'utf8'));
const head = rows.shift().map(h => h.trim());
const need = ['id', 'topic', 'word', 'ipa', 'pos', 'vi', 'ex', 'exVi'];
for (const f of need) if (!head.includes(f)) { console.error(`Thiếu cột "${f}" trong dòng tiêu đề`); process.exit(1); }

const out = rows.map(r => {
  const o = {};
  head.forEach((h, i) => { const v = (r[i] || '').trim(); if (v) o[h] = v; });
  const body = ['id', 'topic', 'word', 'alt', 'ipa', 'pos', 'vi', 'ex', 'exVi', 'note']
    .filter(k => o[k]).map(k => `${k}: ${JSON.stringify(k === 'alt' ? o[k].split('|').map(x => x.trim()).filter(Boolean) : o[k])}`).join(', ');
  return `  { ${body} }`;
});
console.log(out.join(',\n') + ',');
