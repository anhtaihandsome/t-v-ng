#!/usr/bin/env node
/* Kiểm tra dữ liệu từ vựng.  Chạy:  node tools/validate-data.mjs [đường-dẫn-vocab.js]
 * Thoát với mã 1 nếu có lỗi (dùng được trong CI). Cảnh báo (warning) không làm hỏng build. */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const file = process.argv[2] || path.join(here, '..', 'data', 'vocab.js');
const TARGET = 1000;
const POS = new Set(['noun', 'verb', 'adjective', 'adverb', 'phrasal verb', 'preposition', 'conjunction', 'pronoun']);

const sandbox = { window: {} };
vm.createContext(sandbox);
vm.runInContext(fs.readFileSync(file, 'utf8'), sandbox, { filename: file });
const { VOCAB, VOCAB_TOPICS } = sandbox.window;

const errors = [], warnings = [];
const err = (id, m) => errors.push(`[${id}] ${m}`);
const warn = (id, m) => warnings.push(`[${id}] ${m}`);

if (!Array.isArray(VOCAB) || !Array.isArray(VOCAB_TOPICS)) {
  console.error('Thiếu window.VOCAB hoặc window.VOCAB_TOPICS'); process.exit(1);
}
const topicIds = new Set(VOCAB_TOPICS.map(t => t.id));
if (topicIds.size !== VOCAB_TOPICS.length) err('topics', 'id chủ đề bị trùng');

const ids = new Set(), words = new Map(), perTopic = {};
for (const w of VOCAB) {
  const id = w.id || '(thiếu id)';
  for (const f of ['id', 'topic', 'word', 'ipa', 'pos', 'vi', 'ex', 'exVi']) {
    if (typeof w[f] !== 'string' || !w[f].trim()) err(id, `thiếu hoặc rỗng trường "${f}"`);
  }
  if (ids.has(w.id)) err(id, 'id bị trùng'); ids.add(w.id);
  const key = String(w.word || '').toLowerCase().trim();
  if (words.has(key)) err(id, `từ "${w.word}" bị lặp (đã có ở ${words.get(key)})`); else words.set(key, id);
  if (!topicIds.has(w.topic)) err(id, `chủ đề "${w.topic}" không tồn tại`);
  perTopic[w.topic] = (perTopic[w.topic] || 0) + 1;
  if (w.ipa && !/^\/[^/]+\/$/.test(w.ipa)) err(id, 'ipa phải nằm trong dấu /…/');
  if (w.ipa && /[A-Za-z]/.test(w.ipa.replace(/[ɪʊəɜɔɑæɒʌʃʒθðŋɡ]/g, '')) === false) { /* chỉ ký tự IPA: ổn */ }
  for (const p of String(w.pos || '').split(',').map(s => s.trim())) {
    if (!POS.has(p)) err(id, `từ loại "${p}" không hợp lệ (dùng: ${[...POS].join(', ')})`);
  }
  if (w.word && w.word !== w.word.trim()) err(id, 'word có khoảng trắng thừa');
  if (w.alt !== undefined && !(Array.isArray(w.alt) && w.alt.every(a => typeof a === 'string' && a.trim()))) err(id, 'alt phải là mảng chuỗi');
  if (w.ex && !/[.?!]$/.test(w.ex.trim())) warn(id, 'câu ví dụ nên kết thúc bằng dấu câu');
  if (w.exVi && !/[.?!]$/.test(w.exVi.trim())) warn(id, 'bản dịch nên kết thúc bằng dấu câu');
  // Câu ví dụ nên chứa từ (chấp nhận biến thể: bỏ 1 ký tự cuối với từ dài hơn 4 ký tự)
  if (w.word && w.ex) {
    const ex = w.ex.toLowerCase();
    const stem = t => (t.length > 4 ? t.slice(0, -1) : (t.length > 3 && t.endsWith('e') ? t.slice(0, -1) : t));
    const ok = w.word.toLowerCase().split(/\s+/).every(t => ex.includes(stem(t)));
    if (!ok) warn(id, `câu ví dụ có vẻ không chứa từ "${w.word}" (kiểm tra thủ công nếu là dạng biến đổi)`);
  }
}

console.log(`Tệp: ${path.relative(process.cwd(), file)}`);
console.log(`Tổng số từ: ${VOCAB.length}/${TARGET} (${(VOCAB.length / TARGET * 100).toFixed(1)}%), còn thiếu ${Math.max(0, TARGET - VOCAB.length)}`);
for (const t of VOCAB_TOPICS) console.log(`  - ${t.name}: ${perTopic[t.id] || 0} từ`);
if (warnings.length) { console.log(`\nCảnh báo (${warnings.length}):`); warnings.forEach(m => console.log('  ! ' + m)); }
if (errors.length) { console.log(`\nLỖI (${errors.length}):`); errors.forEach(m => console.log('  x ' + m)); process.exit(1); }
console.log('\nDữ liệu hợp lệ ✓');
