# Từ Vựng 1000 – Tự học tiếng Anh cho người Việt

Website tĩnh giúp tích lũy **1.000 từ vựng tiếng Anh thông dụng** theo chủ đề, mặc định **10 từ/ngày**.
Dùng tốt trên máy tính và điện thoại, không cần cài đặt, không cần máy chủ, không cần internet (trừ liên kết tra Cambridge).

## Chạy website

**Cách nhanh nhất:** giải nén thư mục, mở file `index.html` bằng trình duyệt (Chrome, Edge, Safari, Firefox).

**Chạy bằng máy chủ cục bộ** (khuyến nghị nếu muốn thử trên điện thoại cùng mạng Wi-Fi):

```bash
cd vocab1000
python3 -m http.server 8080
# mở http://localhost:8080
```

**Đưa lên mạng:** tải cả thư mục lên GitHub Pages, Netlify, Cloudflare Pages… (chỉ là file tĩnh).

## Cấu trúc thư mục

```
vocab1000/
├── index.html              Khung trang
├── css/style.css           Giao diện (tự đổi sáng/tối theo thiết bị)
├── js/app.js               Toàn bộ logic: tổng quan, học, ôn tập, tìm kiếm, tài khoản, xếp hạng
├── js/cloud.js             Kết nối Supabase (đăng nhập, đồng bộ, xếp hạng)
├── js/config.js            ★ Điền địa chỉ + khóa công khai của Supabase vào đây
├── supabase/schema.sql     Bảng dữ liệu + quy tắc bảo mật, chạy 1 lần trên Supabase
├── data/vocab.js           ★ DỮ LIỆU TỪ VỰNG nằm ở đây
└── tools/
    ├── validate-data.mjs   Kiểm tra dữ liệu (trùng từ, thiếu trường, IPA, chủ đề…)
    └── csv-to-vocab.mjs    Chuyển CSV thành dòng dữ liệu để dán vào vocab.js
```

## Tính năng

- **Tổng quan:** số từ đã học, mục tiêu hôm nay, chuỗi ngày học, tiến độ tới 1.000 từ, tiến độ theo chủ đề.
- **Học theo ngày:** các từ được chia thành bài học theo thứ tự trong `vocab.js`; mỗi bài có đúng *mục tiêu/ngày* từ. Mỗi thẻ có từ, IPA, từ loại, nghĩa, ví dụ + bản dịch, nút nghe, ghi chú Anh-Anh/Anh-Mỹ, liên kết tra Cambridge.
- **Mục tiêu:** chọn 10/15/20/30/50 hoặc nhập số riêng (10–100) trong *Cài đặt*.
- **Đánh dấu:** đã học, cần ôn, yêu thích (★).
- **Ôn tập ngắt quãng:** hộp Leitner với các khoảng 1 → 2 → 4 → 7 → 15 → 30 ngày. Làm sai thì từ quay về đầu hộp và được đánh dấu cần ôn. Hàng đợi ưu tiên từ hay sai và quá hạn lâu.
- **Kiểu ôn mặc định là điền từ theo gợi ý:** hiện nghĩa tiếng Việt, từ loại, số chữ cái, chữ cái đầu và câu ví dụ đã che từ cần điền. Có nút *Gợi ý thêm* (lộ thêm từng chữ cái, không bao giờ lộ hết), *Nghe gợi ý* và *Bỏ qua*. Đúng mà không dùng gợi ý thì lên cấp; đúng nhưng có dùng gợi ý thì mai ôn lại; sai một chữ báo “gần đúng” nhưng vẫn tính là sai chính tả. Chấp nhận chính tả Anh-Mỹ ở trường `alt` (ví dụ practice) và dạng “to + động từ”. Có thể đổi về *Trắc nghiệm* trong Cài đặt.
- **Từ vựng:** tìm theo từ tiếng Anh hoặc nghĩa tiếng Việt (không phân biệt dấu), lọc theo chủ đề và trạng thái.
- **Đăng nhập bằng tên (không cần cài gì):** bấm biểu tượng người ở góc trên bên phải, nhập tên để tạo hồ sơ. Mỗi hồ sơ có tiến độ, chuỗi ngày và cài đặt học riêng, tiện cho nhiều người dùng chung một máy. Có thể chuyển tiến độ chế độ khách vào hồ sơ mới, đổi người dùng, xóa hồ sơ, và xem xếp hạng giữa các hồ sơ trên máy. Hồ sơ lưu trên trình duyệt, **không có mật khẩu và không đồng bộ** sang thiết bị khác. Khi bật tài khoản trực tuyến (mục bên dưới), phần này được thay bằng đăng nhập email + mật khẩu.
- **Lưu tiến độ:** tự động lưu trong `localStorage` của trình duyệt; có xuất/nhập file JSON để sao lưu hoặc chuyển thiết bị.
- **Phát âm:** từ đơn lẻ ưu tiên *bản ghi âm người thật* giọng Anh-Anh (dịch vụ miễn phí dictionaryapi.dev, cần mạng; chỉ dùng khi có bản UK). Không có thì dùng giọng đọc của thiết bị (Web Speech API), tự chọn giọng en-GB tự nhiên nhất (Microsoft Natural, Google UK, Daniel, Serena…), hoặc tự chọn trong Cài đặt. Câu ví dụ luôn dùng giọng thiết bị. Chất lượng giọng thiết bị phụ thuộc máy; Cài đặt có hướng dẫn cài giọng Anh-Anh tốt hơn.

> Tiến độ gắn với từng trình duyệt/thiết bị. Xóa dữ liệu duyệt web hoặc dùng chế độ ẩn danh sẽ làm mất tiến độ, hãy dùng *Cài đặt → Xuất tiến độ* để sao lưu.

## Đưa lên web mà không tốn dung lượng máy

Website chỉ nặng khoảng 50 KB và được đặt trên máy chủ của dịch vụ hosting, nên bạn không cần cài gì thêm và không tốn bộ nhớ máy. Cách nhẹ nhất là làm hoàn toàn trên trình duyệt:

1. Tạo tài khoản **GitHub** (github.com), bấm **New repository**, đặt tên, chọn Public.
2. Trong repo bấm **Add file → Create new file**. Gõ tên file đúng đường dẫn (ví dụ `js/app.js`, gõ dấu `/` để tạo thư mục), dán nội dung file đó vào, bấm **Commit**. Lặp lại cho từng file, hoặc dùng **Upload files** nếu đã giải nén.
3. **Settings → Pages**: Branch `main`, thư mục `/ (root)`, Save. Sau 1–2 phút có link dạng `https://tên-bạn.github.io/tên-repo/`.

Sau khi giải nén xong có thể xóa file zip và thư mục giải nén, website vẫn nằm trên mạng. Muốn sửa sau này, chỉ cần sửa file ngay trên trang GitHub (biểu tượng cây bút) rồi Commit.

## Bật tài khoản và bảng xếp hạng (học cùng bạn bè)

Mặc định website chạy ở **chế độ cá nhân**. Muốn bạn bè đăng nhập, đồng bộ nhiều thiết bị và xem bảng xếp hạng chung, làm một lần các bước sau (miễn phí, khoảng 10 phút). Website vẫn là file tĩnh, dữ liệu dùng chung nằm trên Supabase.

1. Vào **supabase.com**, đăng ký và bấm **New project**. Đặt tên, đặt mật khẩu cơ sở dữ liệu (cất kỹ), chọn khu vực gần bạn (ví dụ Singapore), chờ vài phút.
2. Vào **SQL Editor → New query**, dán toàn bộ nội dung `supabase/schema.sql`, bấm **Run**. Bước này tạo bảng và bật bảo mật: mỗi người chỉ đọc/ghi được tiến độ của mình; bảng xếp hạng chỉ chứa tên hiển thị và số liệu, không có email.
3. Vào **Project Settings → API**, chép hai giá trị: **Project URL** và khóa công khai (**anon public** hoặc **publishable**). Mở `js/config.js` và dán vào `url` và `anonKey`.
   - **Chỉ dùng khóa công khai.** Tuyệt đối không dán khóa `service_role` hoặc `secret`: file này được gửi cho mọi người truy cập.
4. Vào **Authentication → URL Configuration**: đặt **Site URL** là địa chỉ website bạn đã triển khai (ví dụ `https://ten-gi-do.netlify.app/`) và thêm địa chỉ đó vào **Redirect URLs**. Nếu bỏ qua bước này, liên kết trong email xác nhận / đặt lại mật khẩu sẽ dẫn sai chỗ.
5. (Tùy chọn) **Authentication → Providers → Email**: mặc định yêu cầu xác nhận email khi đăng ký, an toàn hơn nhưng bạn bè phải bấm liên kết trong email. Gói miễn phí giới hạn số email gửi mỗi giờ, nếu nhóm đông có thể tắt “Confirm email” hoặc cấu hình SMTP riêng.
6. Triển khai lại website (Netlify / GitHub Pages) với `config.js` đã điền, rồi gửi link cho bạn bè.

### Cách hoạt động
- **Đăng ký / đăng nhập** bằng email và mật khẩu (ít nhất 8 ký tự), có quên và đổi mật khẩu.
- **Đồng bộ tự động:** mỗi lần học hoặc ôn, tiến độ được gộp rồi đẩy lên tài khoản sau vài giây. Hai thiết bị học song song vẫn được gộp: từ nào thay đổi gần nhất thì thắng, số liệu theo ngày lấy giá trị lớn hơn.
- Tiến độ học sẵn trên thiết bị **được gộp vào tài khoản** khi đăng nhập lần đầu. Nếu thiết bị đang giữ tiến độ của tài khoản khác, website hỏi xác nhận rồi chuyển sang tiến độ của tài khoản mới, không trộn lẫn.
- **Xếp hạng chung** cho mọi người đã đăng nhập, hai kiểu: *Tuần này* (số từ mới học trong 7 ngày) và *Tổng số từ*. Mỗi người chỉ thấy tên hiển thị, số từ và chuỗi ngày của nhau. Số liệu của mỗi người được cập nhật khi người đó đồng bộ.
- Nếu `js/config.js` để trống, website dùng chế độ hồ sơ theo tên trên thiết bị (mục Tính năng ở trên). Khi bạn điền Supabase, hồ sơ theo tên tự được thay bằng tài khoản trực tuyến; tiến độ trong các hồ sơ theo tên cũ vẫn nằm trong trình duyệt nhưng không tự chuyển lên tài khoản (hãy dùng Xuất/Nhập tiến độ nếu cần).

### Lưu ý
- Bảng xếp hạng dựa trên số liệu do trình duyệt của mỗi người gửi lên, nên một người rành kỹ thuật có thể tự sửa số của mình. Phù hợp nhóm bạn bè tin cậy, không phù hợp cuộc thi có giải thưởng.
- Bạn bè nên dùng tên hiển thị không chứa thông tin cá nhân, vì tên hiện với mọi người trong bảng xếp hạng.
- Quản trị viên có thể xem và xóa người dùng trong **Authentication → Users** trên Supabase.

## Dữ liệu từ vựng nằm ở đâu?

Tất cả trong **`data/vocab.js`**, gồm hai mảng:

- `window.VOCAB_TOPICS`: danh sách chủ đề (`id`, `name`, `icon`).
- `window.VOCAB`: danh sách từ. Mỗi từ:

```js
{
  id: "fam-01",            // duy nhất, KHÔNG đổi sau khi phát hành
  topic: "family",         // id chủ đề
  word: "parent",
  ipa: "/ˈpeə.rənt/",      // IPA Anh-Anh, đặt trong /…/
  pos: "noun",             // noun | verb | adjective | adverb | phrasal verb | preposition | conjunction | pronoun
  vi: "cha hoặc mẹ; phụ huynh",
  ex: "My parents live in a small town near the coast.",
  exVi: "Bố mẹ tôi sống ở một thị trấn nhỏ gần bờ biển.",
  alt: ["…"],              // không bắt buộc: cách viết khác được chấp nhận khi điền từ (vd. ["practice"])
  note: "…"                // không bắt buộc
}
```

**Hiện tại kho có 100/1.000 từ** (10 chủ đề × 10 từ). Đây là bộ khởi đầu đã được soạn kỹ, không lặp từ.

## Cách bổ sung để đủ 1.000 từ

1. **Lên kế hoạch chủ đề.** Ví dụ 1.000 từ ≈ 15 chủ đề × ~65 từ, hoặc thêm chủ đề mới (thời tiết, cảm xúc, thể thao, giao thông, tiền bạc…) bằng cách thêm vào `VOCAB_TOPICS`.
2. **Soạn từ mới** trong bảng tính, xuất ra CSV (UTF-8) với các cột `id,topic,word,ipa,pos,vi,ex,exVi,note,alt` (alt: nhiều cách viết thì ngăn cách bằng dấu `|`, có thể để trống).
3. **Chuyển CSV thành dữ liệu:**
   ```bash
   node tools/csv-to-vocab.mjs tu-moi.csv > tu-moi.txt
   ```
   rồi dán nội dung vào cuối mảng `VOCAB` trong `data/vocab.js` (trước dấu `];`).
4. **Kiểm tra:**
   ```bash
   node tools/validate-data.mjs
   ```
   Công cụ báo thiếu trường, trùng id, **trùng từ**, chủ đề không tồn tại, IPA sai định dạng, và cảnh báo khi câu ví dụ không chứa từ. Cần Node.js 16+ (không cần cài thêm gói).
5. **Rà soát chất lượng** (xem mục dưới) rồi mở lại website để kiểm tra.

Thứ tự trong `VOCAB` là thứ tự học, nên hãy nhóm các từ cùng chủ đề đứng cạnh nhau. Nếu muốn mỗi ngày học một chủ đề trọn vẹn, nên để số từ mỗi chủ đề là bội số của mục tiêu/ngày (ví dụ 10).

## Chất lượng nội dung và nguồn

- IPA và cách dùng theo hướng **Anh-Anh**, tham khảo cách ghi trong [Cambridge Dictionary](https://dictionary.cambridge.org).
- Nội dung do dự án tự biên soạn. **Không phải trích dẫn** từ Cambridge và **không được Cambridge chứng nhận**. Không sao chép định nghĩa hay câu ví dụ của từ điển.
- Mỗi thẻ từ có liên kết **“Tra Cambridge”** để người học đối chiếu. Hãy đối chiếu IPA, nghĩa và cách dùng từng mục từ với Cambridge Dictionary hoặc người bản ngữ/giáo viên trước khi phát hành rộng rãi.
- Khi bổ sung từ: ví dụ phải tự nhiên, đúng ngữ pháp, đúng nghĩa đang dạy; ghi `note` cho điểm khác biệt Anh-Anh/Anh-Mỹ (ví dụ `practise/practice`, `flat/apartment`, `bill/check`).

## Tùy biến nhanh

- Màu sắc: sửa biến CSS ở đầu `css/style.css`.
- Khoảng cách ôn tập: sửa `INTERVALS` ở đầu `js/app.js`.
- Số từ tối đa mỗi phiên ôn: `QUIZ_SIZE`. Mục tiêu tổng: `TARGET`.
- Khóa lưu trữ: `STORAGE_KEY` (đổi khi bạn thay đổi cấu trúc dữ liệu tiến độ).
