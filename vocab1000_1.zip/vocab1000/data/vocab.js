/*
 * DỮ LIỆU TỪ VỰNG – chỉnh sửa / bổ sung từ tại file này.
 *
 * Mỗi từ là một object với các trường:
 *   id     : mã duy nhất, dạng "<tiền-tố-chủ-đề>-<số>", ví dụ "fam-01". KHÔNG đổi id sau khi đã phát hành
 *            (tiến độ học của người dùng gắn với id).
 *   topic  : id chủ đề (phải có trong VOCAB_TOPICS bên dưới)
 *   word   : từ/cụm từ tiếng Anh (viết thường, trừ danh từ riêng)
 *   ipa    : phiên âm IPA Anh-Anh, đặt trong dấu /.../
 *   pos    : từ loại bằng tiếng Anh: noun, verb, adjective, adverb, phrasal verb, preposition, conjunction, pronoun
 *            (nhiều loại thì ngăn cách bằng dấu phẩy, ví dụ "adjective, adverb")
 *   vi     : nghĩa tiếng Việt
 *   ex     : câu ví dụ tiếng Anh (Anh-Anh)
 *   exVi   : bản dịch câu ví dụ
 *   alt    : (không bắt buộc) mảng cách viết khác được chấp nhận khi điền từ, ví dụ ["practice"] (chính tả Anh-Mỹ)
 *   note   : (không bắt buộc) ghi chú cách dùng / khác biệt Anh-Anh – Anh-Mỹ
 *
 * Thứ tự trong mảng VOCAB chính là thứ tự học: ngày 1 = các từ đầu tiên, v.v.
 *
 * NGUỒN VÀ ĐỘ TIN CẬY:
 * Nội dung do dự án tự biên soạn, tham khảo cách ghi IPA (Anh-Anh) và cách dùng từ theo Cambridge Dictionary
 * (https://dictionary.cambridge.org). Đây KHÔNG phải trích dẫn từ Cambridge và không được Cambridge chứng nhận.
 * Mỗi thẻ từ trong website có liên kết "Tra Cambridge" để người học đối chiếu. Nên rà soát lại IPA trước khi phát hành.
 *
 * Kiểm tra dữ liệu:  node tools/validate-data.mjs
 */

window.VOCAB_TOPICS = [
  { id: "family",   name: "Gia đình",             icon: "👨‍👩‍👧" },
  { id: "food",     name: "Ăn uống",              icon: "🍜" },
  { id: "work",     name: "Công việc",            icon: "💼" },
  { id: "travel",   name: "Du lịch",              icon: "✈️" },
  { id: "health",   name: "Sức khỏe",             icon: "🩺" },
  { id: "shopping", name: "Mua sắm",              icon: "🛍️" },
  { id: "study",    name: "Học tập",              icon: "📚" },
  { id: "tech",     name: "Công nghệ",            icon: "💻" },
  { id: "talk",     name: "Giao tiếp hằng ngày",  icon: "💬" },
  { id: "home",     name: "Nhà cửa",              icon: "🏠" }
];

window.VOCAB = [
  /* ===== Gia đình ===== */
  { id: "fam-01", topic: "family", word: "parent", ipa: "/ˈpeə.rənt/", pos: "noun", vi: "cha hoặc mẹ; phụ huynh", ex: "My parents live in a small town near the coast.", exVi: "Bố mẹ tôi sống ở một thị trấn nhỏ gần bờ biển." },
  { id: "fam-02", topic: "family", word: "sibling", ipa: "/ˈsɪb.lɪŋ/", pos: "noun", vi: "anh, chị, em ruột", ex: "I have two siblings: an older brother and a younger sister.", exVi: "Tôi có hai anh chị em ruột: một anh trai và một em gái." },
  { id: "fam-03", topic: "family", word: "grandmother", ipa: "/ˈɡræn.mʌð.ər/", pos: "noun", vi: "bà (nội hoặc ngoại)", ex: "My grandmother tells the best stories.", exVi: "Bà tôi kể những câu chuyện hay nhất." },
  { id: "fam-04", topic: "family", word: "cousin", ipa: "/ˈkʌz.ən/", pos: "noun", vi: "anh, chị, em họ", ex: "My cousin is coming to stay with us next week.", exVi: "Người em họ của tôi sẽ đến ở với chúng tôi vào tuần sau." },
  { id: "fam-05", topic: "family", word: "relative", ipa: "/ˈrel.ə.tɪv/", pos: "noun", vi: "họ hàng, người thân", ex: "Most of my relatives live in the countryside.", exVi: "Hầu hết họ hàng của tôi sống ở nông thôn." },
  { id: "fam-06", topic: "family", word: "husband", ipa: "/ˈhʌz.bənd/", pos: "noun", vi: "chồng", ex: "Her husband works as an engineer.", exVi: "Chồng cô ấy làm kỹ sư." },
  { id: "fam-07", topic: "family", word: "uncle", ipa: "/ˈʌŋ.kəl/", pos: "noun", vi: "chú, bác, cậu, dượng", ex: "My uncle is a doctor in Hanoi.", exVi: "Chú tôi là bác sĩ ở Hà Nội.", note: "Tiếng Anh không phân biệt chú, bác, cậu, dượng: tất cả đều là uncle." },
  { id: "fam-08", topic: "family", word: "raise", ipa: "/reɪz/", pos: "verb", vi: "nuôi nấng, nuôi dạy (con cái)", ex: "She raised three children on her own.", exVi: "Cô ấy một mình nuôi dạy ba đứa con." },
  { id: "fam-09", topic: "family", word: "grow up", ipa: "/ˌɡrəʊ ˈʌp/", pos: "phrasal verb", vi: "lớn lên, trưởng thành", ex: "Children grow up so quickly.", exVi: "Trẻ con lớn nhanh quá." },
  { id: "fam-10", topic: "family", word: "get along", ipa: "/ˌɡet əˈlɒŋ/", pos: "phrasal verb", vi: "hòa thuận, hợp nhau", ex: "Do you get along with your brother?", exVi: "Bạn có hòa thuận với anh trai mình không?", note: "Thường dùng: get along with + người." },

  /* ===== Ăn uống ===== */
  { id: "food-01", topic: "food", word: "breakfast", ipa: "/ˈbrek.fəst/", pos: "noun", vi: "bữa sáng", ex: "I usually have toast and tea for breakfast.", exVi: "Tôi thường ăn bánh mì nướng và uống trà vào bữa sáng." },
  { id: "food-02", topic: "food", word: "vegetable", ipa: "/ˈvedʒ.tə.bəl/", pos: "noun", vi: "rau, củ", ex: "Try to eat more vegetables every day.", exVi: "Hãy cố ăn nhiều rau củ hơn mỗi ngày." },
  { id: "food-03", topic: "food", word: "fruit", ipa: "/fruːt/", pos: "noun", vi: "trái cây", ex: "We bought some fresh fruit at the market.", exVi: "Chúng tôi mua ít trái cây tươi ở chợ.", note: "Fruit thường là danh từ không đếm được (some fruit)." },
  { id: "food-04", topic: "food", word: "delicious", ipa: "/dɪˈlɪʃ.əs/", pos: "adjective", vi: "ngon", ex: "The soup smells delicious.", exVi: "Món súp có mùi thơm ngon." },
  { id: "food-05", topic: "food", word: "hungry", ipa: "/ˈhʌŋ.ɡri/", pos: "adjective", vi: "đói", ex: "I'm really hungry. I haven't eaten since this morning.", exVi: "Tôi đói quá. Từ sáng đến giờ tôi chưa ăn gì." },
  { id: "food-06", topic: "food", word: "recipe", ipa: "/ˈres.ə.pi/", pos: "noun", vi: "công thức nấu ăn", ex: "Can you give me the recipe for this cake?", exVi: "Bạn cho mình công thức làm chiếc bánh này được không?" },
  { id: "food-07", topic: "food", word: "order", ipa: "/ˈɔː.dər/", pos: "verb", vi: "gọi món; đặt (hàng)", ex: "Are you ready to order?", exVi: "Anh/chị đã sẵn sàng gọi món chưa ạ?" },
  { id: "food-08", topic: "food", word: "bill", ipa: "/bɪl/", pos: "noun", vi: "hóa đơn (nhà hàng, điện, nước…)", ex: "Could we have the bill, please?", exVi: "Làm ơn cho chúng tôi xin hóa đơn.", note: "Anh-Anh dùng the bill khi thanh toán ở nhà hàng; Anh-Mỹ thường nói the check." },
  { id: "food-09", topic: "food", word: "spicy", ipa: "/ˈspaɪ.si/", pos: "adjective", vi: "cay", ex: "I can't eat very spicy food.", exVi: "Tôi không ăn được đồ quá cay." },
  { id: "food-10", topic: "food", word: "cook", ipa: "/kʊk/", pos: "verb", vi: "nấu ăn", ex: "My dad cooks dinner every Sunday.", exVi: "Bố tôi nấu bữa tối vào mỗi Chủ nhật." },

  /* ===== Công việc ===== */
  { id: "work-01", topic: "work", word: "colleague", ipa: "/ˈkɒl.iːɡ/", pos: "noun", vi: "đồng nghiệp", ex: "I'm having lunch with a colleague today.", exVi: "Hôm nay tôi ăn trưa với một đồng nghiệp." },
  { id: "work-02", topic: "work", word: "manager", ipa: "/ˈmæn.ɪ.dʒər/", pos: "noun", vi: "quản lý, trưởng bộ phận", ex: "My manager has asked me to lead the project.", exVi: "Quản lý của tôi đã nhờ tôi dẫn dắt dự án." },
  { id: "work-03", topic: "work", word: "salary", ipa: "/ˈsæl.ər.i/", pos: "noun", vi: "lương (tính theo tháng/năm)", ex: "She earns a good salary at the bank.", exVi: "Cô ấy có mức lương tốt ở ngân hàng." },
  { id: "work-04", topic: "work", word: "meeting", ipa: "/ˈmiː.tɪŋ/", pos: "noun", vi: "cuộc họp", ex: "The meeting starts at nine o'clock.", exVi: "Cuộc họp bắt đầu lúc chín giờ." },
  { id: "work-05", topic: "work", word: "deadline", ipa: "/ˈded.laɪn/", pos: "noun", vi: "hạn chót", ex: "We must finish the report before the deadline.", exVi: "Chúng ta phải hoàn thành báo cáo trước hạn chót." },
  { id: "work-06", topic: "work", word: "apply", ipa: "/əˈplaɪ/", pos: "verb", vi: "nộp đơn, ứng tuyển", ex: "I'm going to apply for a job at a travel company.", exVi: "Tôi định nộp đơn xin việc ở một công ty du lịch.", note: "Cấu trúc: apply for + công việc; apply to + nơi/công ty." },
  { id: "work-07", topic: "work", word: "interview", ipa: "/ˈɪn.tə.vjuː/", pos: "noun", vi: "buổi phỏng vấn", ex: "I have a job interview tomorrow morning.", exVi: "Sáng mai tôi có buổi phỏng vấn xin việc." },
  { id: "work-08", topic: "work", word: "experience", ipa: "/ɪkˈspɪə.ri.əns/", pos: "noun", vi: "kinh nghiệm", ex: "Do you have any experience in sales?", exVi: "Bạn có kinh nghiệm bán hàng không?" },
  { id: "work-09", topic: "work", word: "employee", ipa: "/ɪmˈplɔɪ.iː/", pos: "noun", vi: "nhân viên, người lao động", ex: "The company has about two hundred employees.", exVi: "Công ty có khoảng hai trăm nhân viên." },
  { id: "work-10", topic: "work", word: "schedule", ipa: "/ˈʃed.juːl/", pos: "noun", vi: "lịch trình, thời gian biểu", ex: "My schedule is very busy this week.", exVi: "Tuần này lịch trình của tôi rất bận." },

  /* ===== Du lịch ===== */
  { id: "trav-01", topic: "travel", word: "passport", ipa: "/ˈpɑːs.pɔːt/", pos: "noun", vi: "hộ chiếu", ex: "Don't forget to bring your passport.", exVi: "Đừng quên mang theo hộ chiếu." },
  { id: "trav-02", topic: "travel", word: "luggage", ipa: "/ˈlʌɡ.ɪdʒ/", pos: "noun", vi: "hành lý", ex: "Our luggage was lost at the airport.", exVi: "Hành lý của chúng tôi bị thất lạc ở sân bay.", note: "Luggage là danh từ không đếm được: không nói a luggage hay luggages." },
  { id: "trav-03", topic: "travel", word: "ticket", ipa: "/ˈtɪk.ɪt/", pos: "noun", vi: "vé", ex: "I've booked two tickets to Hue.", exVi: "Tôi đã đặt hai vé đi Huế." },
  { id: "trav-04", topic: "travel", word: "flight", ipa: "/flaɪt/", pos: "noun", vi: "chuyến bay", ex: "Our flight leaves at seven in the morning.", exVi: "Chuyến bay của chúng tôi cất cánh lúc bảy giờ sáng." },
  { id: "trav-05", topic: "travel", word: "reservation", ipa: "/ˌrez.əˈveɪ.ʃən/", pos: "noun", vi: "sự đặt chỗ trước", ex: "I'd like to make a reservation for two nights.", exVi: "Tôi muốn đặt phòng trước cho hai đêm." },
  { id: "trav-06", topic: "travel", word: "tourist", ipa: "/ˈtʊə.rɪst/", pos: "noun", vi: "khách du lịch", ex: "The beach is full of tourists in summer.", exVi: "Bãi biển đầy khách du lịch vào mùa hè." },
  { id: "trav-07", topic: "travel", word: "journey", ipa: "/ˈdʒɜː.ni/", pos: "noun", vi: "chuyến đi (thường là quãng đường dài)", ex: "The journey from Hanoi to Sapa takes about five hours.", exVi: "Chuyến đi từ Hà Nội đến Sa Pa mất khoảng năm tiếng.", note: "Journey nhấn mạnh quãng đường di chuyển; trip là cả chuyến đi chơi." },
  { id: "trav-08", topic: "travel", word: "destination", ipa: "/ˌdes.tɪˈneɪ.ʃən/", pos: "noun", vi: "điểm đến", ex: "Da Lat is a popular destination for couples.", exVi: "Đà Lạt là điểm đến phổ biến của các cặp đôi." },
  { id: "trav-09", topic: "travel", word: "arrive", ipa: "/əˈraɪv/", pos: "verb", vi: "đến nơi", ex: "We arrived at the hotel late at night.", exVi: "Chúng tôi đến khách sạn vào đêm muộn.", note: "arrive at + nơi nhỏ (khách sạn, ga); arrive in + thành phố/quốc gia." },
  { id: "trav-10", topic: "travel", word: "abroad", ipa: "/əˈbrɔːd/", pos: "adverb", vi: "ở nước ngoài, ra nước ngoài", ex: "She studied abroad for two years.", exVi: "Cô ấy đã học ở nước ngoài hai năm.", note: "Không nói to abroad: dùng go abroad, live abroad." },

  /* ===== Sức khỏe ===== */
  { id: "hlth-01", topic: "health", word: "headache", ipa: "/ˈhed.eɪk/", pos: "noun", vi: "đau đầu", ex: "I've got a terrible headache.", exVi: "Tôi đang bị đau đầu kinh khủng." },
  { id: "hlth-02", topic: "health", word: "medicine", ipa: "/ˈmed.sən/", pos: "noun", vi: "thuốc", ex: "Take this medicine twice a day.", exVi: "Hãy uống thuốc này hai lần một ngày." },
  { id: "hlth-03", topic: "health", word: "doctor", ipa: "/ˈdɒk.tər/", pos: "noun", vi: "bác sĩ", ex: "You should see a doctor if the pain continues.", exVi: "Bạn nên đi khám bác sĩ nếu cơn đau vẫn tiếp tục." },
  { id: "hlth-04", topic: "health", word: "healthy", ipa: "/ˈhel.θi/", pos: "adjective", vi: "khỏe mạnh; lành mạnh", ex: "A healthy diet includes plenty of fruit and vegetables.", exVi: "Chế độ ăn lành mạnh gồm nhiều trái cây và rau củ." },
  { id: "hlth-05", topic: "health", word: "exercise", ipa: "/ˈek.sə.saɪz/", pos: "noun", vi: "sự tập thể dục; bài tập", ex: "I try to do some exercise every morning.", exVi: "Tôi cố gắng tập thể dục một chút mỗi sáng." },
  { id: "hlth-06", topic: "health", word: "cough", ipa: "/kɒf/", pos: "verb", vi: "ho", ex: "He has been coughing all night.", exVi: "Anh ấy đã ho suốt đêm." },
  { id: "hlth-07", topic: "health", word: "fever", ipa: "/ˈfiː.vər/", pos: "noun", vi: "sốt", ex: "The child has a high fever.", exVi: "Đứa trẻ bị sốt cao." },
  { id: "hlth-08", topic: "health", word: "pain", ipa: "/peɪn/", pos: "noun", vi: "cơn đau", ex: "I have a pain in my back.", exVi: "Tôi bị đau ở lưng." },
  { id: "hlth-09", topic: "health", word: "recover", ipa: "/rɪˈkʌv.ər/", pos: "verb", vi: "hồi phục, khỏi bệnh", ex: "She is slowly recovering from the flu.", exVi: "Cô ấy đang dần hồi phục sau trận cúm." },
  { id: "hlth-10", topic: "health", word: "appointment", ipa: "/əˈpɔɪnt.mənt/", pos: "noun", vi: "cuộc hẹn (khám bệnh, gặp gỡ)", ex: "I have a doctor's appointment at three o'clock.", exVi: "Tôi có lịch hẹn khám bác sĩ lúc ba giờ." },

  /* ===== Mua sắm ===== */
  { id: "shop-01", topic: "shopping", word: "price", ipa: "/praɪs/", pos: "noun", vi: "giá cả", ex: "The price of petrol keeps going up.", exVi: "Giá xăng cứ tăng mãi.", note: "Petrol là xăng theo Anh-Anh; Anh-Mỹ dùng gas/gasoline." },
  { id: "shop-02", topic: "shopping", word: "discount", ipa: "/ˈdɪs.kaʊnt/", pos: "noun", vi: "giảm giá, chiết khấu", ex: "Students get a ten per cent discount.", exVi: "Sinh viên được giảm giá mười phần trăm." },
  { id: "shop-03", topic: "shopping", word: "cheap", ipa: "/tʃiːp/", pos: "adjective", vi: "rẻ", ex: "This shirt was really cheap.", exVi: "Chiếc áo sơ mi này rẻ thật." },
  { id: "shop-04", topic: "shopping", word: "expensive", ipa: "/ɪkˈspen.sɪv/", pos: "adjective", vi: "đắt", ex: "That restaurant is too expensive for us.", exVi: "Nhà hàng đó quá đắt đối với chúng tôi." },
  { id: "shop-05", topic: "shopping", word: "receipt", ipa: "/rɪˈsiːt/", pos: "noun", vi: "biên lai, hóa đơn mua hàng", ex: "Keep the receipt in case you want to return it.", exVi: "Hãy giữ biên lai phòng khi bạn muốn trả lại hàng.", note: "Chữ p trong receipt là âm câm." },
  { id: "shop-06", topic: "shopping", word: "customer", ipa: "/ˈkʌs.tə.mər/", pos: "noun", vi: "khách hàng", ex: "The shop assistant was very polite to every customer.", exVi: "Nhân viên cửa hàng rất lịch sự với mọi khách hàng." },
  { id: "shop-07", topic: "shopping", word: "afford", ipa: "/əˈfɔːd/", pos: "verb", vi: "đủ khả năng chi trả", ex: "I can't afford a new phone right now.", exVi: "Hiện giờ tôi không đủ tiền mua điện thoại mới.", note: "Thường đi với can/can't/could: can't afford + danh từ hoặc to + động từ." },
  { id: "shop-08", topic: "shopping", word: "refund", ipa: "/ˈriː.fʌnd/", pos: "noun", vi: "sự hoàn tiền", ex: "The shop gave me a full refund.", exVi: "Cửa hàng đã hoàn lại toàn bộ tiền cho tôi." },
  { id: "shop-09", topic: "shopping", word: "size", ipa: "/saɪz/", pos: "noun", vi: "cỡ, kích cỡ", ex: "Do you have this jacket in a larger size?", exVi: "Bạn có chiếc áo khoác này cỡ lớn hơn không?" },
  { id: "shop-10", topic: "shopping", word: "pay", ipa: "/peɪ/", pos: "verb", vi: "trả tiền, thanh toán", ex: "Can I pay by card?", exVi: "Tôi có thể thanh toán bằng thẻ không?", note: "Động từ bất quy tắc: pay – paid – paid." },

  /* ===== Học tập ===== */
  { id: "study-01", topic: "study", word: "lesson", ipa: "/ˈles.ən/", pos: "noun", vi: "bài học, buổi học", ex: "Our first lesson starts at eight.", exVi: "Buổi học đầu tiên của chúng tôi bắt đầu lúc tám giờ." },
  { id: "study-02", topic: "study", word: "homework", ipa: "/ˈhəʊm.wɜːk/", pos: "noun", vi: "bài tập về nhà", ex: "I have a lot of homework tonight.", exVi: "Tối nay tôi có rất nhiều bài tập về nhà.", note: "Homework là danh từ không đếm được." },
  { id: "study-03", topic: "study", word: "exam", ipa: "/ɪɡˈzæm/", pos: "noun", vi: "kỳ thi, bài thi", ex: "She passed her final exam.", exVi: "Cô ấy đã vượt qua kỳ thi cuối kỳ." },
  { id: "study-04", topic: "study", word: "subject", ipa: "/ˈsʌb.dʒekt/", pos: "noun", vi: "môn học; chủ đề", ex: "My favourite subject is history.", exVi: "Môn học yêu thích của tôi là lịch sử." },
  { id: "study-05", topic: "study", word: "practise", alt: ["practice"], ipa: "/ˈpræk.tɪs/", pos: "verb", vi: "luyện tập", ex: "You need to practise speaking every day.", exVi: "Bạn cần luyện nói mỗi ngày.", note: "Anh-Anh: practise (động từ), practice (danh từ). Anh-Mỹ dùng practice cho cả hai." },
  { id: "study-06", topic: "study", word: "remember", ipa: "/rɪˈmem.bər/", pos: "verb", vi: "nhớ", ex: "I can't remember his name.", exVi: "Tôi không nhớ tên anh ấy." },
  { id: "study-07", topic: "study", word: "mistake", ipa: "/mɪˈsteɪk/", pos: "noun", vi: "lỗi, sai sót", ex: "Everyone makes mistakes when they learn a language.", exVi: "Ai cũng mắc lỗi khi học một ngôn ngữ.", note: "Cụm thường gặp: make a mistake (mắc lỗi)." },
  { id: "study-08", topic: "study", word: "improve", ipa: "/ɪmˈpruːv/", pos: "verb", vi: "cải thiện, tiến bộ", ex: "I want to improve my English.", exVi: "Tôi muốn cải thiện tiếng Anh của mình." },
  { id: "study-09", topic: "study", word: "vocabulary", ipa: "/vəˈkæb.jə.lər.i/", pos: "noun", vi: "từ vựng, vốn từ", ex: "Reading helps you build your vocabulary.", exVi: "Đọc sách giúp bạn xây dựng vốn từ vựng." },
  { id: "study-10", topic: "study", word: "explain", ipa: "/ɪkˈspleɪn/", pos: "verb", vi: "giải thích", ex: "Could you explain this rule again?", exVi: "Bạn giải thích lại quy tắc này được không?" },

  /* ===== Công nghệ ===== */
  { id: "tech-01", topic: "tech", word: "computer", ipa: "/kəmˈpjuː.tər/", pos: "noun", vi: "máy tính", ex: "I use my computer for work and study.", exVi: "Tôi dùng máy tính để làm việc và học tập." },
  { id: "tech-02", topic: "tech", word: "password", ipa: "/ˈpɑːs.wɜːd/", pos: "noun", vi: "mật khẩu", ex: "Choose a password that is hard to guess.", exVi: "Hãy chọn mật khẩu khó đoán." },
  { id: "tech-03", topic: "tech", word: "download", ipa: "/ˌdaʊnˈləʊd/", pos: "verb", vi: "tải xuống", ex: "You can download the app for free.", exVi: "Bạn có thể tải ứng dụng này về miễn phí." },
  { id: "tech-04", topic: "tech", word: "website", ipa: "/ˈweb.saɪt/", pos: "noun", vi: "trang web", ex: "Visit our website for more information.", exVi: "Hãy truy cập trang web của chúng tôi để biết thêm thông tin." },
  { id: "tech-05", topic: "tech", word: "battery", ipa: "/ˈbæt.ər.i/", pos: "noun", vi: "pin", ex: "My phone's battery is almost dead.", exVi: "Pin điện thoại của tôi gần hết rồi." },
  { id: "tech-06", topic: "tech", word: "screen", ipa: "/skriːn/", pos: "noun", vi: "màn hình", ex: "The screen is too bright.", exVi: "Màn hình sáng quá." },
  { id: "tech-07", topic: "tech", word: "internet", ipa: "/ˈɪn.tə.net/", pos: "noun", vi: "mạng Internet", ex: "The internet connection is very slow today.", exVi: "Kết nối Internet hôm nay rất chậm." },
  { id: "tech-08", topic: "tech", word: "update", ipa: "/ʌpˈdeɪt/", pos: "verb", vi: "cập nhật", ex: "Remember to update the app regularly.", exVi: "Nhớ cập nhật ứng dụng thường xuyên.", note: "Update cũng là danh từ (/ˈʌp.deɪt/, nhấn âm đầu): a software update." },
  { id: "tech-09", topic: "tech", word: "online", ipa: "/ˌɒnˈlaɪn/", pos: "adjective, adverb", vi: "trực tuyến", ex: "I booked the tickets online.", exVi: "Tôi đã đặt vé trực tuyến." },
  { id: "tech-10", topic: "tech", word: "delete", ipa: "/dɪˈliːt/", pos: "verb", vi: "xóa", ex: "I accidentally deleted the file.", exVi: "Tôi vô tình xóa mất tệp." },

  /* ===== Giao tiếp hằng ngày ===== */
  { id: "talk-01", topic: "talk", word: "apologise", alt: ["apologize"], ipa: "/əˈpɒl.ə.dʒaɪz/", pos: "verb", vi: "xin lỗi", ex: "I must apologise for being late.", exVi: "Tôi xin lỗi vì đã đến muộn.", note: "Cấu trúc: apologise to + người + for + lý do. Anh-Mỹ viết apologize (Anh-Anh cũng chấp nhận)." },
  { id: "talk-02", topic: "talk", word: "invite", ipa: "/ɪnˈvaɪt/", pos: "verb", vi: "mời", ex: "She invited me to her birthday party.", exVi: "Cô ấy đã mời tôi đến dự tiệc sinh nhật." },
  { id: "talk-03", topic: "talk", word: "suggest", ipa: "/səˈdʒest/", pos: "verb", vi: "đề nghị, gợi ý", ex: "I suggest we meet at the café at six.", exVi: "Tôi đề nghị chúng ta gặp nhau ở quán cà phê lúc sáu giờ." },
  { id: "talk-04", topic: "talk", word: "agree", ipa: "/əˈɡriː/", pos: "verb", vi: "đồng ý", ex: "I completely agree with you.", exVi: "Tôi hoàn toàn đồng ý với bạn." },
  { id: "talk-05", topic: "talk", word: "prefer", ipa: "/prɪˈfɜː/", pos: "verb", vi: "thích hơn", ex: "I prefer tea to coffee.", exVi: "Tôi thích trà hơn cà phê.", note: "Cấu trúc: prefer A to B." },
  { id: "talk-06", topic: "talk", word: "introduce", ipa: "/ˌɪn.trəˈdjuːs/", pos: "verb", vi: "giới thiệu", ex: "Let me introduce my friend, Lan.", exVi: "Để tôi giới thiệu bạn tôi, Lan." },
  { id: "talk-07", topic: "talk", word: "mean", ipa: "/miːn/", pos: "verb", vi: "có nghĩa là; muốn nói", ex: "What does this word mean?", exVi: "Từ này có nghĩa là gì?" },
  { id: "talk-08", topic: "talk", word: "repeat", ipa: "/rɪˈpiːt/", pos: "verb", vi: "lặp lại, nhắc lại", ex: "Could you repeat that, please?", exVi: "Bạn nhắc lại câu đó được không?" },
  { id: "talk-09", topic: "talk", word: "forget", ipa: "/fəˈɡet/", pos: "verb", vi: "quên", ex: "Don't forget to call me tonight.", exVi: "Đừng quên gọi cho tôi tối nay.", note: "forget to + động từ = quên không làm việc cần làm." },
  { id: "talk-10", topic: "talk", word: "appreciate", ipa: "/əˈpriː.ʃi.eɪt/", pos: "verb", vi: "trân trọng, biết ơn", ex: "I really appreciate your help.", exVi: "Tôi thật sự biết ơn sự giúp đỡ của bạn." },

  /* ===== Nhà cửa ===== */
  { id: "home-01", topic: "home", word: "apartment", ipa: "/əˈpɑːt.mənt/", pos: "noun", vi: "căn hộ", ex: "They live in a small apartment in the city centre.", exVi: "Họ sống trong một căn hộ nhỏ ở trung tâm thành phố.", note: "Ở Anh người ta cũng hay nói flat; apartment phổ biến hơn trong Anh-Mỹ." },
  { id: "home-02", topic: "home", word: "kitchen", ipa: "/ˈkɪtʃ.ɪn/", pos: "noun", vi: "nhà bếp", ex: "She is making tea in the kitchen.", exVi: "Cô ấy đang pha trà trong bếp." },
  { id: "home-03", topic: "home", word: "bedroom", ipa: "/ˈbed.ruːm/", pos: "noun", vi: "phòng ngủ", ex: "Our house has three bedrooms.", exVi: "Nhà chúng tôi có ba phòng ngủ." },
  { id: "home-04", topic: "home", word: "furniture", ipa: "/ˈfɜː.nɪ.tʃər/", pos: "noun", vi: "đồ nội thất", ex: "We bought some new furniture for the living room.", exVi: "Chúng tôi đã mua ít đồ nội thất mới cho phòng khách.", note: "Furniture là danh từ không đếm được: a piece of furniture." },
  { id: "home-05", topic: "home", word: "rent", ipa: "/rent/", pos: "verb", vi: "thuê (nhà, xe…)", ex: "We rent a small house near the beach.", exVi: "Chúng tôi thuê một căn nhà nhỏ gần bãi biển.", note: "Rent cũng là danh từ: tiền thuê nhà." },
  { id: "home-06", topic: "home", word: "neighbour", alt: ["neighbor"], ipa: "/ˈneɪ.bər/", pos: "noun", vi: "hàng xóm", ex: "Our neighbours are very friendly.", exVi: "Hàng xóm của chúng tôi rất thân thiện.", note: "Anh-Anh: neighbour; Anh-Mỹ: neighbor." },
  { id: "home-07", topic: "home", word: "garden", ipa: "/ˈɡɑː.dən/", pos: "noun", vi: "vườn", ex: "She grows tomatoes in the garden.", exVi: "Cô ấy trồng cà chua trong vườn.", note: "Anh-Anh: garden là khu vườn sau nhà (Anh-Mỹ gọi là yard)." },
  { id: "home-08", topic: "home", word: "clean", ipa: "/kliːn/", pos: "verb", vi: "dọn dẹp, lau chùi", ex: "I clean the house every Saturday.", exVi: "Tôi dọn nhà vào mỗi thứ Bảy.", note: "Clean cũng là tính từ: sạch." },
  { id: "home-09", topic: "home", word: "move", ipa: "/muːv/", pos: "verb", vi: "chuyển nhà; di chuyển", ex: "We're moving to a new house next month.", exVi: "Tháng sau chúng tôi sẽ chuyển đến nhà mới.", note: "Anh-Anh: move house = chuyển nhà." },
  { id: "home-10", topic: "home", word: "floor", ipa: "/flɔː/", pos: "noun", vi: "sàn nhà; tầng", ex: "My office is on the third floor.", exVi: "Văn phòng của tôi ở tầng ba.", note: "Anh-Anh: ground floor là tầng trệt, first floor là tầng nằm ngay trên tầng trệt." }
];
