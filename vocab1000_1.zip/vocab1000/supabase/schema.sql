-- ============================================================
-- Từ Vựng 1000 – cấu trúc dữ liệu cho Supabase
-- Cách chạy: Supabase Dashboard → SQL Editor → New query → dán toàn bộ file này → Run.
-- Có thể chạy lại nhiều lần mà không gây lỗi.
-- ============================================================

-- 1) Bảng hồ sơ công khai (hiện trên bảng xếp hạng). KHÔNG chứa email.
create table if not exists public.profiles (
  id           uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'Người học' check (char_length(display_name) between 1 and 40),
  learned      integer not null default 0 check (learned between 0 and 100000),
  streak       integer not null default 0 check (streak between 0 and 100000),
  week_learned integer not null default 0 check (week_learned between 0 and 100000),
  updated_at   timestamptz not null default now()
);

-- 2) Bảng tiến độ riêng tư (chỉ chủ tài khoản đọc/ghi được).
create table if not exists public.user_progress (
  user_id    uuid primary key references auth.users(id) on delete cascade,
  data       jsonb not null check (octet_length(data::text) < 1000000),
  updated_at timestamptz not null default now()
);

-- 3) Bảo mật cấp hàng (Row Level Security)
alter table public.profiles      enable row level security;
alter table public.user_progress enable row level security;

revoke all on public.profiles      from anon;
revoke all on public.user_progress from anon;
grant usage on schema public to authenticated;
grant select, insert, update on public.profiles to authenticated;
grant select, insert, update, delete on public.user_progress to authenticated;

-- Hồ sơ: mọi người đã đăng nhập xem được bảng xếp hạng; chỉ sửa được hồ sơ của chính mình.
drop policy if exists "profiles_read"       on public.profiles;
drop policy if exists "profiles_insert_own" on public.profiles;
drop policy if exists "profiles_update_own" on public.profiles;
create policy "profiles_read"       on public.profiles for select to authenticated using (true);
create policy "profiles_insert_own" on public.profiles for insert to authenticated with check (auth.uid() = id);
create policy "profiles_update_own" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

-- Tiến độ: chỉ chủ sở hữu.
drop policy if exists "progress_select_own" on public.user_progress;
drop policy if exists "progress_insert_own" on public.user_progress;
drop policy if exists "progress_update_own" on public.user_progress;
drop policy if exists "progress_delete_own" on public.user_progress;
create policy "progress_select_own" on public.user_progress for select to authenticated using (auth.uid() = user_id);
create policy "progress_insert_own" on public.user_progress for insert to authenticated with check (auth.uid() = user_id);
create policy "progress_update_own" on public.user_progress for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "progress_delete_own" on public.user_progress for delete to authenticated using (auth.uid() = user_id);

-- 4) Tự tạo hồ sơ khi có người đăng ký (kể cả khi chưa xác nhận email).
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, display_name)
  values (
    new.id,
    left(coalesce(nullif(trim(new.raw_user_meta_data->>'display_name'), ''), split_part(new.email, '@', 1), 'Người học'), 40)
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();
